-- ============================================================================
-- Session 3 changes: Report/RiskAssessment schema changed significantly
-- (new columns, status is now an enum-backed column), and a brand new
-- comparable_listings table is needed.
--
-- Same situation as the "column contains null values" error you hit
-- before: reports/risk_assessments already have data in your database from
-- earlier testing, and Hibernate's ddl-auto=update cannot safely alter a
-- table with existing rows to match the new shape. Drop and let it
-- recreate them - you're still actively testing, not in production.
-- ============================================================================

DROP TABLE IF EXISTS risk_assessments CASCADE;
DROP TABLE IF EXISTS reports CASCADE;
DROP TABLE IF EXISTS comparable_listings CASCADE;

-- Nothing else needs to be dropped - ddl-auto=update will create
-- comparable_listings fresh (it didn't exist before), and recreate
-- reports/risk_assessments with the new columns, the next time you start
-- the app. No manual CREATE TABLE needed; this file is just documenting
-- what to drop first.
