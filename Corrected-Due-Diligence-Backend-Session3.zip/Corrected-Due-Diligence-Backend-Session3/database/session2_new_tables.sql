-- ============================================================================
-- Session 2 additions: Flood Zone, Permits, Environmental, Utilities,
-- Reports, Risk Assessments.
-- You do NOT need to run this by hand - spring.jpa.hibernate.ddl-auto=update
-- will create all of these automatically the first time the app starts.
-- Included for reference / manual inspection only.
-- ============================================================================

CREATE TABLE IF NOT EXISTS flood_zone_data (
    id                     BIGSERIAL PRIMARY KEY,
    property_id            BIGINT NOT NULL UNIQUE REFERENCES properties(id),
    flood_zone             VARCHAR(255),
    flood_risk_rating      VARCHAR(255),
    firm_panel_number      VARCHAR(255),
    panel_effective_date   DATE,
    base_flood_elevation   DOUBLE PRECISION,
    ground_elevation       DOUBLE PRECISION,
    source                 VARCHAR(255),
    created_at             TIMESTAMP
);

CREATE TABLE IF NOT EXISTS permits (
    id             BIGSERIAL PRIMARY KEY,
    property_id    BIGINT NOT NULL REFERENCES properties(id),
    permit_number  VARCHAR(255),
    permit_type    VARCHAR(255),
    status         VARCHAR(255),
    issue_date     DATE,
    final_date     DATE,
    valuation      DOUBLE PRECISION,
    description    TEXT,
    source         VARCHAR(255),
    created_at     TIMESTAMP
);

CREATE TABLE IF NOT EXISTS environmental_records (
    id             BIGSERIAL PRIMARY KEY,
    property_id    BIGINT NOT NULL REFERENCES properties(id),
    facility_name  VARCHAR(255),
    facility_id    VARCHAR(255),
    program_type   VARCHAR(255),
    status         VARCHAR(255),
    address        VARCHAR(255),
    latitude       DOUBLE PRECISION,
    longitude      DOUBLE PRECISION,
    source         VARCHAR(255),
    created_at     TIMESTAMP
);

CREATE TABLE IF NOT EXISTS utility_information (
    id              BIGSERIAL PRIMARY KEY,
    property_id     BIGINT NOT NULL REFERENCES properties(id),
    utility_type    VARCHAR(255) NOT NULL,
    provider_name   VARCHAR(255),
    account_number  VARCHAR(255),
    monthly_cost    DOUBLE PRECISION,
    notes           TEXT,
    source          VARCHAR(255),   -- "Manual Entry" label = the entering user's full name
    created_at      TIMESTAMP,
    updated_at      TIMESTAMP
);

CREATE TABLE IF NOT EXISTS reports (
    id                  BIGSERIAL PRIMARY KEY,
    property_id         BIGINT NOT NULL REFERENCES properties(id),
    requested_by        VARCHAR(255),
    status              VARCHAR(50) NOT NULL,   -- PENDING / COMPLETED
    created_at          TIMESTAMP,
    risk_score          DOUBLE PRECISION,
    executive_summary   TEXT
);

CREATE TABLE IF NOT EXISTS risk_assessments (
    id          BIGSERIAL PRIMARY KEY,
    report_id   BIGINT NOT NULL REFERENCES reports(id),
    category    VARCHAR(50) NOT NULL,   -- TAX_DUE / FLOOD_RISK / ZONING_COMPLIANCE / PERMIT_COMPLIANCE / OWNERSHIP_VERIFICATION / LEGAL_RISK
    indicator   TEXT,
    score       DOUBLE PRECISION NOT NULL,
    notes       TEXT
);
