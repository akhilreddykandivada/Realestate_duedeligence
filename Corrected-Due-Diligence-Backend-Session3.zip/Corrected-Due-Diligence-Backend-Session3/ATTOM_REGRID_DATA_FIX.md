# ATTOM / REGRID data fix

## Why the old ownership response was returning `ownerName: null`

The previous `DueDiligenceService` treated the database as a permanent cache:

```text
if ownership_records has any row -> return it
```

A previous ATTOM mapping created this row:

```json
{
  "ownerName": null,
  "ownershipType": "Individual"
}
```

Because the row existed, the backend never called ATTOM again. This made the bad row look like an ATTOM problem even when the API could provide owner data.

This version fixes that behavior.

## What changed

### Ownership
- Broken cached ownership rows are deleted and refreshed.
- ATTOM `/property/detailowner` and `/property/basicprofile` are read as raw JSON.
- Owner information is extracted defensively from `owner`, `owners`, `owner1`, `owner2`, etc.
- Supports several ATTOM naming variants for full name, first/middle/last name and company name.
- Does not create an `Individual` row when there is no owner name.
- Acquisition/deed/sale dates are parsed when ATTOM supplies them.
- ATTOM ID is saved to `properties.attom_id` when available.

### Tax history
- Empty/broken cached tax rows are refreshed.
- ATTOM `/assessment` is read as raw JSON so nested/variant assessment and tax fields can be found.
- Supports `taxyear`, `taxYear`, `assessedValue`, `assdTtlValue`, `taxAmount`, `taxAmt`, and `amount`.
- A tax row is saved whenever at least one useful tax field is available.

### Zoning / REGRID
- Broken empty zoning rows are refreshed.
- REGRID parcel fields are matched case-insensitively.
- More zoning/land-use field names are supported.
- A successful parcel response is saved even when the account does not expose a zoning classification.
- REGRID parcel identifiers such as `ll_uuid`, `regrid_id`, `parcel_id`, `parcelnumb`, or `id` are saved to `properties.regrid_id`.

### Property entity
The entity now maps:

```text
properties.attom_id
properties.regrid_id
```

No `user_id` was added or removed.

## How to test

1. Start the backend with the same environment variables you already use.
2. Make sure `ATTOM_API_KEY` is set.
3. Make sure `REGRID_API_TOKEN` is set for zoning.
4. Call:

```text
GET /api/properties/1/ownership
GET /api/properties/1/tax-history
GET /api/properties/1/zoning
```

5. Then verify:

```sql
SELECT id, address, attom_id, regrid_id
FROM properties
ORDER BY id;

SELECT *
FROM ownership_records
ORDER BY id;

SELECT *
FROM tax_history
ORDER BY id;

SELECT *
FROM zoning_information
ORDER BY id;
```

The first ownership request will no longer return the old `ownerName = NULL` cache row.

## Important

The code cannot manufacture ATTOM or REGRID data. If the provider account/API returns no owner, tax, parcel, or zoning information, the endpoint now reports the actual provider/data problem instead of silently inserting misleading rows.

Do not put API keys into source files. Keep them in environment variables.
