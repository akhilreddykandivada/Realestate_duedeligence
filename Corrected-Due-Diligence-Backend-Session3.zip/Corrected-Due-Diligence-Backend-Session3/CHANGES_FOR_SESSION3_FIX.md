# Session 3 backend fixes

Only the required backend changes were made:

1. **Fixed the iText `setBold()` compile issue**
   - `PdfReportGenerator.java`
   - Bold formatting is now applied to `Text` elements inside `Paragraph`.
   - No report content or business logic was otherwise changed.

2. **Fixed the PostgreSQL database target**
   - `application.properties`
   - Changed the datasource from `realestate` to `realestate_due_diligence`.

No frontend source files were changed because the uploaded frontend structure and API paths match the backend endpoints reviewed.

## Important before running

Set these environment variables as required by your setup:

- `DB_PASSWORD`
- `JWT_SECRET`
- `ATTOM_API_KEY`
- `REGRID_API_TOKEN`
- Optional: Google/Nominatim, FEMA, Shovels, EPA, RapidAPI variables

The project uses `ddl-auto=update`, so start with the intended empty `realestate_due_diligence` database.
