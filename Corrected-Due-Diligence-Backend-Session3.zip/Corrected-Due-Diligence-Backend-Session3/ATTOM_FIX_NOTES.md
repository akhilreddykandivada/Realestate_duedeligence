# ATTOM integration fix

- PostgreSQL database is `realestate_due_diligence`.
- ATTOM requests use `address1` for the stored street address and `address2` for the stored city/state/ZIP location, matching the verified Postman request.
- `Accept: application/json` is sent explicitly.
- ATTOM HTTP 429/5xx responses are retried; 400/401/403/404 responses are not retried.
- The backend no longer hides the final ATTOM HTTP error behind a generic temporary-unavailable message.
- ATTOM DTOs now support `identifier.attomId` and the owner structure returned under `assessment.owner`.
- ATTOM tax DTOs now support `assessment.tax.taxAmt`.
- Ownership service falls back to `assessment.owner` when the provider does not return a top-level owner list.

The exact ATTOM key must remain in the `ATTOM_API_KEY` environment variable. No key is stored in source code.

Note: Maven compilation could not be executed in this environment because the Maven wrapper distribution could not be downloaded from Maven Central. Please compile/run in IntelliJ where the project's Maven dependencies are available.

- Broken cached ownership rows are now detected and refreshed instead of being returned forever.
- ATTOM owner and assessment extraction uses raw JSON fallback logic to tolerate provider field variations.
