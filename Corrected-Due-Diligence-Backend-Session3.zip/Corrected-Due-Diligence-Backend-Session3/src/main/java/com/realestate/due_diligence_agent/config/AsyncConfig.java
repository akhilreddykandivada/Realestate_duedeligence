package com.realestate.due_diligence_agent.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

/**
 * Dedicated thread pool for the parallel due-diligence aggregation calls,
 * so they don't compete with (or exhaust) the JVM's shared common
 * ForkJoinPool that other parts of the app might rely on.
 */
@Configuration
public class AsyncConfig {

    @Bean
    public Executor dueDiligenceExecutor() {
        return Executors.newFixedThreadPool(7, r -> {
            Thread t = new Thread(r);
            t.setName("due-diligence-" + t.getId());
            t.setDaemon(true);
            return t;
        });
    }
}
