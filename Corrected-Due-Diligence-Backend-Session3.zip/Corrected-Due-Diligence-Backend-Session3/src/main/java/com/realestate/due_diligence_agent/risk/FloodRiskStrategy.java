package com.realestate.due_diligence_agent.risk;

import com.realestate.due_diligence_agent.dto.DueDiligenceAggregateResponse;
import com.realestate.due_diligence_agent.dto.RiskCategoryResult;
import com.realestate.due_diligence_agent.entity.FloodZoneData;
import org.springframework.stereotype.Component;

@Component
public class FloodRiskStrategy implements RiskCategoryStrategy {

    @Override
    public String getCategory() { return "FLOOD_RISK"; }

    @Override
    public double getWeight() { return 0.20; }

    @Override
    public RiskCategoryResult evaluate(DueDiligenceAggregateResponse data) {
        if (data.getFloodZone() == null || !"SUCCESS".equals(data.getFloodZone().getStatus())
                || data.getFloodZone().getData() == null) {
            return RiskCategoryResult.builder()
                    .category(getCategory())
                    .score(50.0)
                    .indicator("Flood zone could not be determined")
                    .notes("FEMA NFHL data was unavailable for this property - treated as moderate/unknown risk until verified.")
                    .build();
        }

        FloodZoneData flood = data.getFloodZone().getData();
        String rating = flood.getFloodRiskRating() != null ? flood.getFloodRiskRating() : "UNKNOWN";
        String zone = flood.getFloodZone() != null ? flood.getFloodZone() : "unspecified";

        double score = switch (rating) {
            case "HIGH" -> 85.0;
            case "MODERATE" -> 50.0;
            case "MINIMAL" -> 10.0;
            default -> 50.0;
        };

        return RiskCategoryResult.builder()
                .category(getCategory())
                .score(score)
                .indicator("FEMA flood zone " + zone + " (" + rating + " risk)")
                .notes(flood.getBaseFloodElevation() != null
                        ? "Base flood elevation on record: " + flood.getBaseFloodElevation() + " ft."
                        : "No base flood elevation on record for this parcel.")
                .build();
    }
}
