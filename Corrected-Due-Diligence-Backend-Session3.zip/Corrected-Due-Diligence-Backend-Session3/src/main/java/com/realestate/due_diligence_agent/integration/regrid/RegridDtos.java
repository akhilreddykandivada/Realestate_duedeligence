package com.realestate.due_diligence_agent.integration.regrid;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import java.util.List;
import java.util.Map;

/** GeoJSON-shaped DTOs used by the Regrid parcel lookup response. */
public final class RegridDtos {
    private RegridDtos() {}

    @Data @JsonIgnoreProperties(ignoreUnknown = true)
    public static class ParcelLookupResponse {
        private String type;
        private List<Feature> features;
    }

    @Data @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Feature {
        private String type;
        private Map<String, Object> properties;
        private Geometry geometry;
    }

    @Data @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Geometry {
        private String type;
        private Object coordinates;
    }
}
