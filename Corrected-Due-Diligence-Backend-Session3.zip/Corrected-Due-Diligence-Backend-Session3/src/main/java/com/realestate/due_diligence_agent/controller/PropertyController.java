package com.realestate.due_diligence_agent.controller;

import com.realestate.due_diligence_agent.dto.AddressValidationRequest;
import com.realestate.due_diligence_agent.dto.AddressValidationResponse;
import com.realestate.due_diligence_agent.dto.DueDiligenceAggregateResponse;
import com.realestate.due_diligence_agent.dto.TimelineEntry;
import com.realestate.due_diligence_agent.entity.EnvironmentalRecord;
import com.realestate.due_diligence_agent.entity.FloodZoneData;
import com.realestate.due_diligence_agent.entity.OwnershipRecord;
import com.realestate.due_diligence_agent.entity.Permit;
import com.realestate.due_diligence_agent.entity.TaxHistory;
import com.realestate.due_diligence_agent.entity.ZoningInformation;
import com.realestate.due_diligence_agent.entity.Property;
import com.realestate.due_diligence_agent.service.AddressValidationService;
import com.realestate.due_diligence_agent.service.DueDiligenceAggregationService;
import com.realestate.due_diligence_agent.service.EnvironmentalRecordService;
import com.realestate.due_diligence_agent.service.FloodZoneService;
import com.realestate.due_diligence_agent.service.PermitService;
import com.realestate.due_diligence_agent.service.PropertyHistoryService;
import com.realestate.due_diligence_agent.service.PropertyService;
import com.realestate.due_diligence_agent.service.DueDiligenceService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/properties")
@RequiredArgsConstructor
public class PropertyController {

    private final PropertyService propertyService;
    private final AddressValidationService addressValidationService;
    private final PropertyHistoryService propertyHistoryService;
    private final DueDiligenceService dueDiligenceService;
    private final FloodZoneService floodZoneService;
    private final PermitService permitService;
    private final EnvironmentalRecordService environmentalRecordService;
    private final DueDiligenceAggregationService dueDiligenceAggregationService;

    @GetMapping
    public ResponseEntity<List<Property>> getAllProperties() {
        return ResponseEntity.ok(propertyService.getAllProperties());
    }

    @GetMapping("/search")
    public ResponseEntity<List<Property>> searchByAddress(
            @RequestParam String address) {
        return ResponseEntity.ok(propertyService.searchByAddress(address));
    }

    @PostMapping("/validate_address")
    public ResponseEntity<AddressValidationResponse> validateAddress(
            @Valid @RequestBody AddressValidationRequest request) {
        return ResponseEntity.ok(addressValidationService.validate(request.getAddress()));
    }

    @GetMapping("/{id}/history")
    public ResponseEntity<List<TimelineEntry>> getPropertyHistory(
            @PathVariable Long id) {
        return ResponseEntity.ok(propertyHistoryService.getHistory(id));
    }


    @GetMapping("/{id}/ownership")
    public ResponseEntity<List<OwnershipRecord>> getOwnership(@PathVariable Long id) {
        return ResponseEntity.ok(dueDiligenceService.getOwnership(id));
    }

    @GetMapping("/{id}/tax-history")
    public ResponseEntity<List<TaxHistory>> getTaxHistory(@PathVariable Long id) {
        return ResponseEntity.ok(dueDiligenceService.getTaxHistory(id));
    }

    @GetMapping("/{id}/zoning")
    public ResponseEntity<ZoningInformation> getZoning(@PathVariable Long id) {
        return ResponseEntity.ok(dueDiligenceService.getZoning(id));
    }

    @GetMapping("/{id}/flood-zone")
    public ResponseEntity<FloodZoneData> getFloodZone(@PathVariable Long id) {
        return ResponseEntity.ok(floodZoneService.getFloodZone(id));
    }

    @GetMapping("/{id}/permits")
    public ResponseEntity<List<Permit>> getPermits(@PathVariable Long id) {
        return ResponseEntity.ok(permitService.getPermits(id));
    }

    @GetMapping("/{id}/environmental")
    public ResponseEntity<List<EnvironmentalRecord>> getEnvironmentalRecords(@PathVariable Long id) {
        return ResponseEntity.ok(environmentalRecordService.getEnvironmentalRecords(id));
    }

    @GetMapping("/{id}/due-diligence")
    public ResponseEntity<DueDiligenceAggregateResponse> getDueDiligence(@PathVariable Long id) {
        return ResponseEntity.ok(dueDiligenceAggregationService.aggregate(id));
    }

    @GetMapping("/{id}")
    public ResponseEntity<Property> getPropertyById(
            @PathVariable Long id) {
        return ResponseEntity.ok(propertyService.getPropertyById(id));
    }
}

