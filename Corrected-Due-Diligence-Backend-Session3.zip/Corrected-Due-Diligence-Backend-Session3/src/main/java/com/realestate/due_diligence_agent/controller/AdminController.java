package com.realestate.due_diligence_agent.controller;

import com.realestate.due_diligence_agent.entity.Property;
import com.realestate.due_diligence_agent.entity.User;
import com.realestate.due_diligence_agent.repository.PropertyRepository;
import com.realestate.due_diligence_agent.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/admin")
@RequiredArgsConstructor
public class AdminController {
    private final PropertyRepository propertyRepository;
    private final UserRepository userRepository;

    @GetMapping("/dashboard")
    public String dashboard() {
        return "Admin dashboard reached - protected by the /api/admin/** rule in SecurityConfig.";
    }

    @PutMapping("/properties/{propertyId}/owner/{userId}")
    public ResponseEntity<String> assignPropertyOwner(
            @PathVariable Long propertyId,
            @PathVariable Long userId) {
        Property property = propertyRepository.findById(propertyId)
                .orElseThrow(() -> new RuntimeException("Property not found with id: " + propertyId));
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found with id: " + userId));
        property.setOwner(user);
        propertyRepository.save(property);
        return ResponseEntity.ok("Property " + propertyId + " is now owned by user " + userId + ".");
    }
}
