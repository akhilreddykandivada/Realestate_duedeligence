package com.realestate.due_diligence_agent.dto;

import lombok.*;

import java.time.LocalDate;

@Getter @Setter @Builder @NoArgsConstructor @AllArgsConstructor
public class TimelineEntry {
    private LocalDate date;
    private String label;
    private String description;
}
