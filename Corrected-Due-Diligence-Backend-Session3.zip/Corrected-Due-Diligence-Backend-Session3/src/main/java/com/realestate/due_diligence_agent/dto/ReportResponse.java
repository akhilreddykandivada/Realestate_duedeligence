package com.realestate.due_diligence_agent.dto;

import com.realestate.due_diligence_agent.comparable.entity.ComparableListing;
import lombok.*;

import java.time.LocalDateTime;
import java.util.List;

@Getter @Setter @Builder @NoArgsConstructor @AllArgsConstructor
public class ReportResponse {
    private Long id;
    private Long propertyId;
    private String requestedBy;
    private String status;
    private LocalDateTime createdAt;
    private Double riskScore;
    private String executiveSummary;
    private String failureReason;
    private String pdfUrl;
    private String excelUrl;
    private List<RiskCategoryResult> riskCategories;
    private List<TimelineEntry> timeline;
    private List<ComparableListing> comparables;
}
