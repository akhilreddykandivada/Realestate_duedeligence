package com.realestate.due_diligence_agent.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "flood_zone_data")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class FloodZoneData {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "property_id", nullable = false, unique = true)
    private Property property;

    @Column(name = "flood_zone")
    private String floodZone;

    @Column(name = "flood_risk_rating")
    private String floodRiskRating;

    @Column(name = "firm_panel_number")
    private String firmPanelNumber;

    @Column(name = "panel_effective_date")
    private LocalDate panelEffectiveDate;

    @Column(name = "base_flood_elevation")
    private Double baseFloodElevation;

    @Column(name = "ground_elevation")
    private Double groundElevation;

    private String source;

    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @PrePersist
    protected void onCreate() { this.createdAt = LocalDateTime.now(); }
}
