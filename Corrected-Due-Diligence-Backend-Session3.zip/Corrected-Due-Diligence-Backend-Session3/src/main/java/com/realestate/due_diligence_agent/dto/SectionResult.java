package com.realestate.due_diligence_agent.dto;

import lombok.*;

/**
 * Wraps one section of the aggregated due-diligence response so a failure
 * in one external service never takes down the whole response - the other
 * sections still come back with real data, and this one clearly says why
 * it didn't.
 */
@Getter @Setter @Builder @NoArgsConstructor @AllArgsConstructor
public class SectionResult<T> {

    /** SUCCESS or FAILED */
    private String status;
    private T data;
    private String errorMessage;

    public static <T> SectionResult<T> success(T data) {
        return SectionResult.<T>builder().status("SUCCESS").data(data).build();
    }

    public static <T> SectionResult<T> failed(String errorMessage) {
        return SectionResult.<T>builder().status("FAILED").errorMessage(errorMessage).build();
    }
}
