package com.realestate.due_diligence_agent.integration.fema;

import com.fasterxml.jackson.databind.JsonNode;
import lombok.Getter;

import java.util.ArrayList;
import java.util.List;

/**
 * FEMA NFHL is an Esri ArcGIS REST FeatureServer/MapServer. Every layer
 * query returns the same envelope: {"features": [{"attributes": {...}}]}.
 * Field names inside "attributes" vary slightly by NFHL release, so
 * FemaNfhlClient reads them defensively rather than binding to a fixed POJO.
 */
public class FemaDtos {

    @Getter
    public static class QueryResult {
        private final List<JsonNode> featureAttributes = new ArrayList<>();

        public static QueryResult from(JsonNode body) {
            QueryResult result = new QueryResult();
            if (body != null && body.has("features")) {
                for (JsonNode feature : body.get("features")) {
                    if (feature.has("attributes")) {
                        result.featureAttributes.add(feature.get("attributes"));
                    }
                }
            }
            return result;
        }

        public boolean isEmpty() {
            return featureAttributes.isEmpty();
        }

        public JsonNode first() {
            return featureAttributes.isEmpty() ? null : featureAttributes.get(0);
        }
    }
}
