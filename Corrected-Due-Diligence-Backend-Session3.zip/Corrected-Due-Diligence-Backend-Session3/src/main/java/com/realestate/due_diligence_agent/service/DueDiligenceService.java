package com.realestate.due_diligence_agent.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.realestate.due_diligence_agent.entity.OwnershipRecord;
import com.realestate.due_diligence_agent.entity.Property;
import com.realestate.due_diligence_agent.entity.TaxHistory;
import com.realestate.due_diligence_agent.entity.ZoningInformation;
import com.realestate.due_diligence_agent.integration.ExternalDataNotFoundException;
import com.realestate.due_diligence_agent.integration.attom.AttomClient;
import com.realestate.due_diligence_agent.integration.attom.AttomDtos;
import com.realestate.due_diligence_agent.integration.regrid.RegridClient;
import com.realestate.due_diligence_agent.integration.regrid.RegridDtos;
import com.realestate.due_diligence_agent.repository.OwnershipRecordRepository;
import com.realestate.due_diligence_agent.repository.PropertyRepository;
import com.realestate.due_diligence_agent.repository.TaxHistoryRepository;
import com.realestate.due_diligence_agent.repository.ZoningInformationRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.*;
import java.util.regex.Pattern;

@Service
@RequiredArgsConstructor
public class DueDiligenceService {
    private final PropertyRepository propertyRepository;
    private final OwnershipRecordRepository ownershipRepository;
    private final TaxHistoryRepository taxHistoryRepository;
    private final ZoningInformationRepository zoningRepository;
    private final AttomClient attomClient;
    private final RegridClient regridClient;

    @Transactional
    public List<OwnershipRecord> getOwnership(Long propertyId) {
        Property property = getProperty(propertyId);

        // Do not trust an old/broken cache row. The previous implementation
        // saved a row with ownerName=NULL and then returned it forever.
        List<OwnershipRecord> existing = ownershipRepository.findByPropertyId(propertyId);
        if (hasUsableOwnership(existing)) {
            return existing;
        }
        if (!existing.isEmpty()) {
            ownershipRepository.deleteAll(existing);
        }

        JsonNode basic = attomClient.raw(
                "/property/basicprofile",
                property.getAddress(),
                property.getLocation(),
                "ATTOM basic profile");

        JsonNode detail = attomClient.raw(
                "/property/detailowner",
                property.getAddress(),
                property.getLocation(),
                "ATTOM owner details");

        // Save the ATTOM identifier when ATTOM provides one.
        String attomId = firstNonBlank(
                findRecursive(detail, "attomid", "attomId", "id"),
                findRecursive(basic, "attomid", "attomId"));
        if (StringUtils.hasText(attomId)) {
            property.setAttomId(attomId);
            propertyRepository.save(property);
        }

        LinkedHashMap<String, JsonNode> ownerNodes = new LinkedHashMap<>();
        collectOwnerNodes(detail, ownerNodes);
        collectOwnerNodes(basic, ownerNodes);

        List<OwnershipRecord> records = new ArrayList<>();
        for (JsonNode owner : ownerNodes.values()) {
            String ownerName = extractOwnerName(owner);
            if (!StringUtils.hasText(ownerName)) {
                continue;
            }

            String company = firstNonBlank(
                    text(owner, "companyName", "companyname", "company"),
                    text(owner, "corporateName", "corporatename"));
            String corporate = text(owner, "corporateIndicator", "corporateindicator", "isCorporate");
            String ownershipType = StringUtils.hasText(company)
                    || "Y".equalsIgnoreCase(corporate)
                    || "YES".equalsIgnoreCase(corporate)
                    ? "Corporate" : "Individual";

            LocalDate acquisitionDate = parseDate(firstNonBlank(
                    text(owner, "acquisitionDate", "acquisitiondate"),
                    text(owner, "deedDate", "deeddate"),
                    text(owner, "saleTransDate", "saletransdate"),
                    text(owner, "saleRecDate", "salerecdate")));

            String paymentStatus = firstNonBlank(
                    text(owner, "paymentStatus", "paymentstatus"),
                    text(owner, "taxStatus", "taxstatus"));

            records.add(OwnershipRecord.builder()
                    .property(property)
                    .ownerName(ownerName)
                    .ownershipType(ownershipType)
                    .acquisitionDate(acquisitionDate)
                    .paymentStatus(paymentStatus)
                    .build());
        }

        if (records.isEmpty()) {
            throw new ExternalDataNotFoundException(
                    "ATTOM returned owner details, but no owner name was found for property "
                            + propertyId + ". Check the ATTOM /property/detailowner response in the console.");
        }

        return ownershipRepository.saveAll(records);
    }

    @Transactional
    public List<TaxHistory> getTaxHistory(Long propertyId) {
        Property property = getProperty(propertyId);

        List<TaxHistory> existing =
                taxHistoryRepository.findByPropertyIdOrderByTaxYearDesc(propertyId);
        if (hasUsableTax(existing)) {
            return existing;
        }
        if (!existing.isEmpty()) {
            taxHistoryRepository.deleteAll(existing);
        }

        JsonNode response = attomClient.raw(
                "/assessment",
                property.getAddress(),
                property.getLocation(),
                "ATTOM assessment");

        String attomId = firstNonBlank(
                findRecursive(response, "attomid", "attomId", "id"));
        if (StringUtils.hasText(attomId) && !StringUtils.hasText(property.getAttomId())) {
            property.setAttomId(attomId);
            propertyRepository.save(property);
        }

        JsonNode assessment = firstObject(response, "assessment");
        if (assessment == null) {
            // Some ATTOM responses nest the assessment differently. Searching
            // recursively makes the integration tolerant of that variation.
            assessment = findObjectRecursive(response, "assessment");
        }

        Integer taxYear = integerValue(firstNonBlank(
                text(assessment, "taxyear", "taxYear", "year"),
                findRecursive(response, "taxyear", "taxYear")));

        Double assessedValue = numberValue(firstNonBlank(
                text(assessment, "assessedValue", "assdTtlValue"),
                findRecursive(response, "assessedValue", "assdTtlValue")));

        Double taxAmount = numberValue(firstNonBlank(
                text(assessment, "taxAmount"),
                text(firstObject(assessment, "tax"), "taxAmt", "amount", "taxAmount"),
                findRecursive(response, "taxAmt", "taxAmount")));

        if (taxYear == null && assessedValue == null && taxAmount == null) {
            throw new ExternalDataNotFoundException(
                    "ATTOM assessment returned no usable tax year, assessed value or tax amount for property "
                            + propertyId + ".");
        }

        TaxHistory record = TaxHistory.builder()
                .property(property)
                .taxYear(taxYear)
                .assessedValue(assessedValue)
                .taxAmount(taxAmount)
                .paymentStatus(firstNonBlank(
                        text(assessment, "paymentStatus", "paymentstatus"),
                        text(firstObject(assessment, "tax"), "paymentStatus", "paymentstatus")))
                .build();

        return List.of(taxHistoryRepository.save(record));
    }

    @Transactional
    public ZoningInformation getZoning(Long propertyId) {
        Property property = getProperty(propertyId);
        Optional<ZoningInformation> existing = zoningRepository.findByPropertyId(propertyId);
        if (existing.isPresent() && hasUsableZoning(existing.get())) {
            return existing.get();
        }
        existing.ifPresent(zoningRepository::delete);

        RegridDtos.ParcelLookupResponse response = regridClient.lookup(
                property.getLatitude(),
                property.getLongitude(),
                property.getAddress());

        RegridDtos.Feature feature = firstFeature(response, property);
        Map<String, Object> fields = feature.getProperties();

        if (fields == null || fields.isEmpty()) {
            throw new ExternalDataNotFoundException(
                    "REGRID returned a parcel but no parcel properties for property " + propertyId + ".");
        }

        String regridId = find(fields,
                "ll_uuid", "regrid_id", "regridid", "parcel_id", "parcelid", "id", "parcelnumb");
        if (StringUtils.hasText(regridId)) {
            property.setRegridId(regridId);
            propertyRepository.save(property);
        }

        String zoningClass = find(fields,
                "zoning", "zoning_class", "zoning_classification", "zoningcode",
                "zoning_code", "zone", "zone_type", "zoning_description");

        String landUse = find(fields,
                "landuse", "land_use", "land_use_code", "landusecode",
                "usecode", "use_code", "usedesc", "use_desc", "landuse_description");

        String setbacks = find(fields,
                "setback", "setbacks", "setback_requirements");

        String compliance = find(fields,
                "zoning_compliance", "zoning_status", "compliance");

        // A parcel can be successfully found even when the Regrid account
        // does not expose zoning fields. Save the parcel result rather than
        // silently losing the lookup.
        ZoningInformation zoning = ZoningInformation.builder()
                .property(property)
                .zoningClassification(zoningClass)
                .landUse(landUse)
                .setbackRequirements(setbacks)
                .zoningCompliance(compliance)
                .build();

        return zoningRepository.save(zoning);
    }

    private boolean hasUsableOwnership(List<OwnershipRecord> records) {
        return records != null && !records.isEmpty()
                && records.stream().anyMatch(r -> StringUtils.hasText(r.getOwnerName()));
    }

    private boolean hasUsableTax(List<TaxHistory> records) {
        return records != null && !records.isEmpty()
                && records.stream().anyMatch(r ->
                r.getTaxYear() != null || r.getAssessedValue() != null || r.getTaxAmount() != null);
    }

    private boolean hasUsableZoning(ZoningInformation zoning) {
        return zoning != null && (
                StringUtils.hasText(zoning.getZoningClassification())
                        || StringUtils.hasText(zoning.getLandUse())
                        || StringUtils.hasText(zoning.getSetbackRequirements())
                        || StringUtils.hasText(zoning.getZoningCompliance()));
    }

    private Property getProperty(Long id) {
        return propertyRepository.findById(id)
                .orElseThrow(() -> new ExternalDataNotFoundException("Property not found with id: " + id));
    }

    private RegridDtos.Feature firstFeature(
            RegridDtos.ParcelLookupResponse response, Property property) {
        if (response == null || response.getFeatures() == null || response.getFeatures().isEmpty()) {
            throw new ExternalDataNotFoundException(
                    "REGRID returned no parcel for property " + property.getId() + ".");
        }
        return response.getFeatures().get(0);
    }

    private void collectOwnerNodes(JsonNode node, Map<String, JsonNode> result) {
        if (node == null || node.isNull()) return;

        if (node.isObject()) {
            Iterator<Map.Entry<String, JsonNode>> fields = node.fields();
            while (fields.hasNext()) {
                Map.Entry<String, JsonNode> entry = fields.next();
                String key = entry.getKey().toLowerCase(Locale.ROOT);
                JsonNode value = entry.getValue();

                if (isOwnerKey(key)) {
                    collectOwnerValue(value, result);
                } else {
                    collectOwnerNodes(value, result);
                }
            }
        } else if (node.isArray()) {
            for (JsonNode child : node) collectOwnerNodes(child, result);
        }
    }

    private boolean isOwnerKey(String key) {
        return key.equals("owner")
                || key.equals("owners")
                || key.equals("owner1")
                || key.equals("owner2")
                || key.equals("owner3")
                || key.equals("owner4")
                || key.equals("owner5");
    }

    private void collectOwnerValue(JsonNode value, Map<String, JsonNode> result) {
        if (value == null || value.isNull()) return;

        if (value.isArray()) {
            for (JsonNode item : value) collectOwnerValue(item, result);
            return;
        }

        if (!value.isObject()) return;

        String name = extractOwnerName(value);
        String identity = firstNonBlank(
                name,
                text(value, "mailingAddressOneLine", "mailingaddressoneline"),
                value.toString());

        result.putIfAbsent(identity.trim().toLowerCase(Locale.ROOT), value);
    }

    private String extractOwnerName(JsonNode owner) {
        if (owner == null || owner.isNull()) return null;

        String company = firstNonBlank(
                text(owner, "companyName", "companyname", "company"),
                text(owner, "corporateName", "corporatename"));

        String full = firstNonBlank(
                text(owner, "fullName", "fullname", "ownerName", "ownername",
                        "fullNameAndMi", "fullnameandmi"),
                text(owner, "name"));

        String personal = join(
                text(owner, "firstNameAndMi", "firstnameandmi"),
                text(owner, "lastName", "lastname"));

        if (!StringUtils.hasText(personal)) {
            personal = join(
                    text(owner, "firstName", "firstname"),
                    text(owner, "middleName", "middlename"),
                    text(owner, "lastName", "lastname", "lastNameAndSuffix", "lastnameandsuffix"));
        }

        return firstNonBlank(full, personal, company);
    }

    private String text(JsonNode node, String... keys) {
        if (node == null || node.isNull()) return null;
        for (String key : keys) {
            JsonNode value = findDirect(node, key);
            if (value != null && !value.isNull() && !value.isContainerNode()) {
                String result = value.asText();
                if (StringUtils.hasText(result)) return result.trim();
            }
        }
        return null;
    }

    private JsonNode findDirect(JsonNode node, String key) {
        if (node == null || !node.isObject()) return null;
        JsonNode exact = node.get(key);
        if (exact != null) return exact;

        Iterator<Map.Entry<String, JsonNode>> it = node.fields();
        String target = normalize(key);
        while (it.hasNext()) {
            Map.Entry<String, JsonNode> entry = it.next();
            if (normalize(entry.getKey()).equals(target)) return entry.getValue();
        }
        return null;
    }

    private String findRecursive(JsonNode node, String... keys) {
        if (node == null || node.isNull()) return null;

        for (String key : keys) {
            String value = text(node, key);
            if (StringUtils.hasText(value)) return value;
        }

        if (node.isObject()) {
            Iterator<JsonNode> it = node.elements();
            while (it.hasNext()) {
                String found = findRecursive(it.next(), keys);
                if (StringUtils.hasText(found)) return found;
            }
        } else if (node.isArray()) {
            for (JsonNode child : node) {
                String found = findRecursive(child, keys);
                if (StringUtils.hasText(found)) return found;
            }
        }
        return null;
    }

    private JsonNode firstObject(JsonNode node, String key) {
        if (node == null || node.isNull()) return null;
        JsonNode direct = findDirect(node, key);
        return direct != null && direct.isObject() ? direct : null;
    }

    private JsonNode findObjectRecursive(JsonNode node, String key) {
        if (node == null || node.isNull()) return null;
        JsonNode direct = firstObject(node, key);
        if (direct != null) return direct;

        if (node.isObject() || node.isArray()) {
            Iterator<JsonNode> it = node.elements();
            while (it.hasNext()) {
                JsonNode found = findObjectRecursive(it.next(), key);
                if (found != null) return found;
            }
        }
        return null;
    }

    private String find(Map<String, Object> values, String... keys) {
        if (values == null) return null;

        for (String key : keys) {
            Object value = values.get(key);
            if (value == null) value = values.get(key.toLowerCase(Locale.ROOT));
            if (value != null && StringUtils.hasText(String.valueOf(value))) {
                return String.valueOf(value);
            }
        }

        for (Map.Entry<String, Object> entry : values.entrySet()) {
            String normalized = normalize(entry.getKey());
            for (String key : keys) {
                if (normalized.equals(normalize(key))
                        && entry.getValue() != null
                        && StringUtils.hasText(String.valueOf(entry.getValue()))) {
                    return String.valueOf(entry.getValue());
                }
            }
        }
        return null;
    }

    private String normalize(String value) {
        return value == null ? "" : value.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]", "");
    }

    private String firstNonBlank(String... values) {
        for (String value : values) {
            if (StringUtils.hasText(value)) return value.trim();
        }
        return null;
    }

    private String join(String... values) {
        List<String> parts = new ArrayList<>();
        for (String value : values) {
            if (StringUtils.hasText(value)) parts.add(value.trim());
        }
        return String.join(" ", parts);
    }

    private Integer integerValue(String value) {
        if (!StringUtils.hasText(value)) return null;
        try {
            return (int) Double.parseDouble(value.replace(",", "").trim());
        } catch (NumberFormatException ex) {
            return null;
        }
    }

    private Double numberValue(String value) {
        if (!StringUtils.hasText(value)) return null;
        try {
            return Double.parseDouble(value.replace("$", "").replace(",", "").trim());
        } catch (NumberFormatException ex) {
            return null;
        }
    }

    private LocalDate parseDate(String value) {
        if (!StringUtils.hasText(value)) return null;
        String cleaned = value.trim();
        String[] patterns = {
                "yyyy-MM-dd", "yyyyMMdd", "MM/dd/yyyy", "M/d/yyyy",
                "yyyy-MM-dd'T'HH:mm:ss", "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"
        };
        for (String pattern : patterns) {
            try {
                if (pattern.contains("H")) {
                    return LocalDate.parse(cleaned, DateTimeFormatter.ofPattern(pattern)
                            .withLocale(Locale.ROOT));
                }
                return LocalDate.parse(cleaned, DateTimeFormatter.ofPattern(pattern));
            } catch (DateTimeParseException ignored) {
            }
        }
        if (cleaned.length() >= 10) {
            try {
                return LocalDate.parse(cleaned.substring(0, 10));
            } catch (DateTimeParseException ignored) {
            }
        }
        return null;
    }
}
