package com.realestate.due_diligence_agent.risk;

import com.realestate.due_diligence_agent.dto.DueDiligenceAggregateResponse;
import com.realestate.due_diligence_agent.dto.RiskCategoryResult;

/**
 * One risk category (tax, flood, zoning, permits, ownership, legal). Every
 * implementation is stateless and takes the property's already-gathered
 * due-diligence data as input, so RiskAssessmentService only has to fetch
 * that data once and hand the same object to all six strategies.
 */
public interface RiskCategoryStrategy {

    /** Stable machine-readable category key, e.g. "TAX_DUE". */
    String getCategory();

    /** Relative weight (0-1) this category contributes to the overall score. All six should sum to 1.0. */
    double getWeight();

    RiskCategoryResult evaluate(DueDiligenceAggregateResponse data);
}
