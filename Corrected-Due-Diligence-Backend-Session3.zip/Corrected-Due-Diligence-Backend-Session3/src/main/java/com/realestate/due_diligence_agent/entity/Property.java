package com.realestate.due_diligence_agent.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "properties")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Property {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String address;

    private String location;

    @Column(name = "property_type")
    private String type;

    private Integer bedrooms;

    private Integer bathrooms;

    @Column(name = "square_feet")
    private Double squareFeet;

    @Column(name = "year_built")
    private Integer yearBuilt;

    private Double latitude;

    private Double longitude;

    @Column(name = "attom_id")
    private String attomId;

    @Column(name = "regrid_id")
    private String regridId;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id")
    private User owner;
}
