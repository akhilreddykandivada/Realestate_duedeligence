package com.realestate.due_diligence_agent.repository;

import com.realestate.due_diligence_agent.entity.UtilityInformation;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface UtilityInformationRepository extends JpaRepository<UtilityInformation, Long> {
    List<UtilityInformation> findByPropertyId(Long propertyId);
    Optional<UtilityInformation> findByIdAndPropertyId(Long id, Long propertyId);
}
