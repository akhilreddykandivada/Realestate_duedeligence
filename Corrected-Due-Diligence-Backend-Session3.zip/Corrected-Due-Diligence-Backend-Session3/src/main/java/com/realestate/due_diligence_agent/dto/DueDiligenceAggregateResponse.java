package com.realestate.due_diligence_agent.dto;

import com.realestate.due_diligence_agent.entity.*;
import lombok.*;

import java.util.List;

@Getter @Setter @Builder @NoArgsConstructor @AllArgsConstructor
public class DueDiligenceAggregateResponse {

    private Long propertyId;
    private SectionResult<List<OwnershipRecord>> ownership;
    private SectionResult<List<TaxHistory>> taxHistory;
    private SectionResult<ZoningInformation> zoning;
    private SectionResult<FloodZoneData> floodZone;
    private SectionResult<List<Permit>> permits;
    private SectionResult<List<EnvironmentalRecord>> environmental;
    private SectionResult<List<UtilityInformation>> utilities;
}
