package com.realestate.due_diligence_agent.risk;

import com.realestate.due_diligence_agent.dto.DueDiligenceAggregateResponse;
import com.realestate.due_diligence_agent.dto.RiskCategoryResult;
import com.realestate.due_diligence_agent.entity.TaxHistory;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.util.List;
import java.util.Locale;

/**
 * Uses the property's tax history to flag unpaid/overdue tax risk.
 * paymentStatus often comes back null from ATTOM's basicprofile/detailowner
 * packages (it isn't populated on that data path today) - that's treated
 * as "unknown", a moderate score, not a false "all clear".
 */
@Component
public class TaxDueAnalysisStrategy implements RiskCategoryStrategy {

    private static final List<String> DELINQUENT_TERMS = List.of("DELINQUENT", "OVERDUE", "UNPAID", "PAST DUE", "LATE");
    private static final List<String> CURRENT_TERMS = List.of("PAID", "CURRENT", "UP TO DATE", "UP-TO-DATE");

    @Override
    public String getCategory() { return "TAX_DUE"; }

    @Override
    public double getWeight() { return 0.20; }

    @Override
    public RiskCategoryResult evaluate(DueDiligenceAggregateResponse data) {
        if (data.getTaxHistory() == null || !"SUCCESS".equals(data.getTaxHistory().getStatus())
                || data.getTaxHistory().getData() == null || data.getTaxHistory().getData().isEmpty()) {
            return RiskCategoryResult.builder()
                    .category(getCategory())
                    .score(50.0)
                    .indicator("No tax history on file")
                    .notes("Tax history could not be retrieved, so tax-due risk cannot be evaluated - treated as moderate/unknown risk.")
                    .build();
        }

        List<TaxHistory> history = data.getTaxHistory().getData();
        TaxHistory mostRecent = history.stream()
                .max((a, b) -> compareYear(a.getTaxYear(), b.getTaxYear()))
                .orElse(history.get(0));

        String status = mostRecent.getPaymentStatus();
        String normalized = status == null ? "" : status.toUpperCase(Locale.ROOT);

        if (containsAny(normalized, DELINQUENT_TERMS)) {
            return RiskCategoryResult.builder()
                    .category(getCategory())
                    .score(90.0)
                    .indicator("Delinquent taxes on record for " + safeYear(mostRecent))
                    .notes("Payment status reported as \"" + status + "\" - unpaid property tax is a lien risk for the buyer/lender.")
                    .build();
        }

        if (containsAny(normalized, CURRENT_TERMS)) {
            return RiskCategoryResult.builder()
                    .category(getCategory())
                    .score(10.0)
                    .indicator("Taxes current as of " + safeYear(mostRecent))
                    .notes("Most recent tax record (" + safeYear(mostRecent) + ") reports payment status \"" + status + "\".")
                    .build();
        }

        return RiskCategoryResult.builder()
                .category(getCategory())
                .score(45.0)
                .indicator("Tax payment status unknown for " + safeYear(mostRecent))
                .notes("Assessment data was found for " + safeYear(mostRecent)
                        + " but the source did not report a payment status - verify directly with the county tax assessor.")
                .build();
    }

    private boolean containsAny(String normalized, List<String> terms) {
        if (!StringUtils.hasText(normalized)) return false;
        return terms.stream().anyMatch(normalized::contains);
    }

    private int compareYear(Integer a, Integer b) {
        if (a == null) return -1;
        if (b == null) return 1;
        return a.compareTo(b);
    }

    private String safeYear(TaxHistory taxHistory) {
        return taxHistory.getTaxYear() != null ? String.valueOf(taxHistory.getTaxYear()) : "an unspecified year";
    }
}
