package com.realestate.due_diligence_agent.repository;

import com.realestate.due_diligence_agent.entity.Report;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ReportRepository extends JpaRepository<Report, Long> {
    List<Report> findByRequestedByUserIdOrderByCreatedAtDesc(Long userId);
}
