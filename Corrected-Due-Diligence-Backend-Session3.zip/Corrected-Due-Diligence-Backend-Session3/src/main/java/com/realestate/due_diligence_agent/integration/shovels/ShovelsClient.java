package com.realestate.due_diligence_agent.integration.shovels;

import com.fasterxml.jackson.databind.JsonNode;
import com.realestate.due_diligence_agent.integration.ExternalApiException;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatusCode;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.util.retry.Retry;

import java.time.Duration;
import java.time.LocalDate;

/**
 * Shovels.ai building-permits client - GET /permits/search, authenticated
 * via the X-API-Key header (never a query param, per the mentor spec).
 *
 * The free trial has a SHARED 250-request cap across the whole team, so
 * this is only ever called by PermitService when the database has no
 * existing rows for a property (see PermitService's database-first check) -
 * never call this client directly from a controller.
 */
@Component
@RequiredArgsConstructor
public class ShovelsClient {

    private final WebClient.Builder webClientBuilder;
    private WebClient webClient;

    @Value("${shovels.base-url:https://api.shovels.ai/v2}")
    private String baseUrl;
    @Value("${shovels.search-path:/permits/search}")
    private String searchPath;
    @Value("${shovels.api-key:${SHOVELS_API_KEY:}}")
    private String apiKey;
    @Value("${shovels.retry.max-attempts:3}")
    private long maxAttempts;
    @Value("${shovels.retry.delay-ms:600}")
    private long retryDelayMs;

    @PostConstruct
    private void init() {
        this.webClient = webClientBuilder.baseUrl(baseUrl).build();
    }

    public ShovelsDtos.SearchResult search(String geoId, String address, LocalDate permitFrom,
                                            LocalDate permitTo, String propertyType) {
        if (!StringUtils.hasText(apiKey)) {
            throw new ExternalApiException("Shovels API key is not configured. Set SHOVELS_API_KEY before requesting permits.");
        }
        try {
            JsonNode body = webClient
                    .get()
                    .uri(uriBuilder -> {
                        uriBuilder.path(searchPath);
                        if (StringUtils.hasText(geoId)) uriBuilder.queryParam("geo_id", geoId);
                        else if (StringUtils.hasText(address)) uriBuilder.queryParam("address", address);
                        if (permitFrom != null) uriBuilder.queryParam("permit_from", permitFrom.toString());
                        if (permitTo != null) uriBuilder.queryParam("permit_to", permitTo.toString());
                        if (StringUtils.hasText(propertyType)) uriBuilder.queryParam("property_type", propertyType);
                        return uriBuilder.build();
                    })
                    .header("X-API-Key", apiKey)
                    .retrieve()
                    .onStatus(HttpStatusCode::isError, status -> status.createException())
                    .bodyToMono(JsonNode.class)
                    .retryWhen(Retry.backoff(Math.max(1, maxAttempts - 1), Duration.ofMillis(Math.max(100, retryDelayMs)))
                            .filter(t -> !(t instanceof IllegalArgumentException))
                            .onRetryExhaustedThrow((spec, signal) -> new ExternalApiException(
                                    "Shovels permit search is temporarily unavailable.", signal.failure())))
                    .block();

            return ShovelsDtos.SearchResult.from(body);
        } catch (ExternalApiException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new ExternalApiException("Unable to process the Shovels permit search response.", ex);
        }
    }
}
