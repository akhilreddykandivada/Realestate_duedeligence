package com.realestate.due_diligence_agent.risk;

import com.realestate.due_diligence_agent.dto.DueDiligenceAggregateResponse;
import com.realestate.due_diligence_agent.dto.RiskCategoryResult;
import com.realestate.due_diligence_agent.entity.ZoningInformation;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.util.Locale;

@Component
public class ZoningComplianceStrategy implements RiskCategoryStrategy {

    @Override
    public String getCategory() { return "ZONING_COMPLIANCE"; }

    @Override
    public double getWeight() { return 0.15; }

    @Override
    public RiskCategoryResult evaluate(DueDiligenceAggregateResponse data) {
        if (data.getZoning() == null || !"SUCCESS".equals(data.getZoning().getStatus())
                || data.getZoning().getData() == null) {
            return RiskCategoryResult.builder()
                    .category(getCategory())
                    .score(50.0)
                    .indicator("Zoning data unavailable")
                    .notes("Regrid parcel/zoning data could not be retrieved - compliance cannot be verified.")
                    .build();
        }

        ZoningInformation zoning = data.getZoning().getData();
        String compliance = zoning.getZoningCompliance();
        String normalized = compliance == null ? "" : compliance.toUpperCase(Locale.ROOT);

        if (normalized.contains("NON") || normalized.contains("VIOLATION")) {
            return RiskCategoryResult.builder()
                    .category(getCategory())
                    .score(80.0)
                    .indicator("Zoning non-compliance reported")
                    .notes("Regrid reports compliance status \"" + compliance + "\" for land use \""
                            + safe(zoning.getLandUse()) + "\".")
                    .build();
        }

        if (normalized.contains("COMPLIANT")) {
            return RiskCategoryResult.builder()
                    .category(getCategory())
                    .score(15.0)
                    .indicator("Zoning compliant")
                    .notes("Land use \"" + safe(zoning.getLandUse()) + "\" reported compliant under classification \""
                            + safe(zoning.getZoningClassification()) + "\".")
                    .build();
        }

        boolean hasSomeData = StringUtils.hasText(zoning.getZoningClassification()) || StringUtils.hasText(zoning.getLandUse());
        return RiskCategoryResult.builder()
                .category(getCategory())
                .score(hasSomeData ? 40.0 : 55.0)
                .indicator(hasSomeData ? "Zoning classification on file, compliance status unclear" : "No usable zoning data")
                .notes("Classification: " + safe(zoning.getZoningClassification())
                        + " | Land use: " + safe(zoning.getLandUse())
                        + " | Setback requirements: " + safe(zoning.getSetbackRequirements())
                        + " - Regrid did not report an explicit compliance flag; manual review recommended.")
                .build();
    }

    private String safe(String value) {
        return StringUtils.hasText(value) ? value : "not on record";
    }
}
