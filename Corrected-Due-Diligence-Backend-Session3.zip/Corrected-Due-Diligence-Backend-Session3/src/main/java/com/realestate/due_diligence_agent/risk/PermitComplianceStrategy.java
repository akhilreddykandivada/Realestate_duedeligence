package com.realestate.due_diligence_agent.risk;

import com.realestate.due_diligence_agent.dto.DueDiligenceAggregateResponse;
import com.realestate.due_diligence_agent.dto.RiskCategoryResult;
import com.realestate.due_diligence_agent.entity.Permit;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.util.List;
import java.util.Locale;

@Component
public class PermitComplianceStrategy implements RiskCategoryStrategy {

    private static final List<String> OPEN_TERMS = List.of("OPEN", "IN PROGRESS", "PENDING", "ISSUED");
    private static final List<String> PROBLEM_TERMS = List.of("EXPIRED", "VOID", "REVOKED", "FAILED", "DENIED");

    @Override
    public String getCategory() { return "PERMIT_COMPLIANCE"; }

    @Override
    public double getWeight() { return 0.15; }

    @Override
    public RiskCategoryResult evaluate(DueDiligenceAggregateResponse data) {
        if (data.getPermits() == null || !"SUCCESS".equals(data.getPermits().getStatus())
                || data.getPermits().getData() == null) {
            return RiskCategoryResult.builder()
                    .category(getCategory())
                    .score(50.0)
                    .indicator("Permit history unavailable")
                    .notes("Shovels permit data could not be retrieved for this property.")
                    .build();
        }

        List<Permit> permits = data.getPermits().getData();
        if (permits.isEmpty()) {
            return RiskCategoryResult.builder()
                    .category(getCategory())
                    .score(30.0)
                    .indicator("No permit history on file")
                    .notes("No permits found - this can mean a clean history, or that no permitted work has ever been recorded for this address.")
                    .build();
        }

        long problemCount = permits.stream().filter(p -> matches(p.getStatus(), PROBLEM_TERMS)).count();
        long openWithoutFinalCount = permits.stream()
                .filter(p -> matches(p.getStatus(), OPEN_TERMS) && p.getFinalDate() == null)
                .count();

        if (problemCount > 0) {
            return RiskCategoryResult.builder()
                    .category(getCategory())
                    .score(Math.min(95.0, 60.0 + problemCount * 10))
                    .indicator(problemCount + " permit(s) with an expired/void/failed status")
                    .notes("Out of " + permits.size() + " permits on file, " + problemCount
                            + " were flagged with a problematic status - review for unresolved work.")
                    .build();
        }

        if (openWithoutFinalCount > 0) {
            return RiskCategoryResult.builder()
                    .category(getCategory())
                    .score(Math.min(75.0, 40.0 + openWithoutFinalCount * 10))
                    .indicator(openWithoutFinalCount + " permit(s) issued but never finalized")
                    .notes("Open permits without a final inspection can block financing/resale until closed out.")
                    .build();
        }

        return RiskCategoryResult.builder()
                .category(getCategory())
                .score(15.0)
                .indicator(permits.size() + " permit(s) on file, none flagged")
                .notes("No expired, void, or unfinaled permits detected in the " + permits.size() + " record(s) reviewed.")
                .build();
    }

    private boolean matches(String status, List<String> terms) {
        if (!StringUtils.hasText(status)) return false;
        String normalized = status.toUpperCase(Locale.ROOT);
        return terms.stream().anyMatch(normalized::contains);
    }
}
