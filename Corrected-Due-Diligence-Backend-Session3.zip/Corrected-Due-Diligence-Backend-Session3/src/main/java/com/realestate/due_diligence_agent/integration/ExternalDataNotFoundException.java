package com.realestate.due_diligence_agent.integration;

public class ExternalDataNotFoundException extends RuntimeException {
    public ExternalDataNotFoundException(String message) { super(message); }
}
