package com.realestate.due_diligence_agent.service;

import com.realestate.due_diligence_agent.dto.TimelineEntry;
import com.realestate.due_diligence_agent.integration.ExternalDataNotFoundException;
import com.realestate.due_diligence_agent.repository.OwnershipRecordRepository;
import com.realestate.due_diligence_agent.repository.PermitRepository;
import com.realestate.due_diligence_agent.repository.PropertyRepository;
import com.realestate.due_diligence_agent.repository.TaxHistoryRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * GET /api/properties/{id}/history now returns the property's actual
 * chronological timeline (ownership changes, tax assessments, permits) via
 * PropertyTimelineBuilder, rather than an internal sync-event audit log.
 * Purely reads what's already in the database - no external API calls, and
 * an empty timeline is returned as an empty list rather than an error.
 */
@Service
@RequiredArgsConstructor
public class PropertyHistoryService {

    private final PropertyRepository propertyRepository;
    private final OwnershipRecordRepository ownershipRecordRepository;
    private final TaxHistoryRepository taxHistoryRepository;
    private final PermitRepository permitRepository;
    private final PropertyTimelineBuilder propertyTimelineBuilder;

    @Transactional(readOnly = true)
    public List<TimelineEntry> getHistory(Long propertyId) {
        if (!propertyRepository.existsById(propertyId)) {
            throw new ExternalDataNotFoundException("Property not found with id: " + propertyId);
        }

        return propertyTimelineBuilder.build(
                ownershipRecordRepository.findByPropertyId(propertyId),
                taxHistoryRepository.findByPropertyIdOrderByTaxYearDesc(propertyId),
                permitRepository.findByPropertyId(propertyId)
        );
    }
}
