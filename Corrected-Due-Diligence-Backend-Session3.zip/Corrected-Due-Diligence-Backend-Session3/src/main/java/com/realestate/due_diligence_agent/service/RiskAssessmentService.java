package com.realestate.due_diligence_agent.service;

import com.realestate.due_diligence_agent.dto.*;
import com.realestate.due_diligence_agent.entity.*;
import com.realestate.due_diligence_agent.integration.ExternalDataNotFoundException;
import com.realestate.due_diligence_agent.repository.PropertyRepository;
import com.realestate.due_diligence_agent.repository.ReportRepository;
import com.realestate.due_diligence_agent.repository.RiskAssessmentRepository;
import com.realestate.due_diligence_agent.risk.RiskCategoryStrategy;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class RiskAssessmentService {

    private final PropertyRepository propertyRepository;
    private final ReportRepository reportRepository;
    private final RiskAssessmentRepository riskAssessmentRepository;
    private final DueDiligenceAggregationService aggregationService;

    /** All RiskCategoryStrategy beans, auto-collected by Spring. */
    private final List<RiskCategoryStrategy> strategies;

    /**
     * POST /api/properties/{id}/risk-assessment - standalone quick-run
     * endpoint: gathers due-diligence data, runs all six strategies, saves
     * its own report. Kept separate from ReportService's full generation
     * flow (which also runs comparables, timeline, and summary
     * generation) since the original spec asked for this as its own thing.
     */
    @Transactional
    public RiskAssessmentResponse runRiskAssessment(Long propertyId) {
        Property property = getProperty(propertyId);
        DueDiligenceAggregateResponse data = aggregationService.aggregate(propertyId);

        Report report = Report.builder()
                .property(property)
                .requestedBy(currentUserLabel())
                .requestedByUser(currentUserOrNull())
                .status(ReportStatus.IN_PROGRESS)
                .build();
        report = reportRepository.save(report);

        RiskOutcome outcome = runStrategies(report, data);

        report.setStatus(ReportStatus.COMPLETED);
        report.setRiskScore(outcome.overallScore());
        report.setExecutiveSummary(outcome.summary());
        reportRepository.save(report);

        return RiskAssessmentResponse.builder()
                .reportId(report.getId())
                .propertyId(propertyId)
                .overallRiskScore(outcome.overallScore())
                .executiveSummary(outcome.summary())
                .categories(outcome.results())
                .build();
    }

    /**
     * Reusable core: runs all six strategies against already-gathered
     * due-diligence data, saves one RiskAssessment row per category
     * against the given (already-persisted) report, and returns the
     * results plus weighted overall score. This is what ReportService's
     * full orchestration flow calls into - it does NOT create its own
     * report, the caller owns that.
     */
    @Transactional
    public RiskOutcome runStrategies(Report report, DueDiligenceAggregateResponse data) {
        List<RiskCategoryResult> results = new ArrayList<>();
        double weightedSum = 0.0;
        double weightTotal = 0.0;

        for (RiskCategoryStrategy strategy : strategies) {
            RiskCategoryResult result = strategy.evaluate(data);
            results.add(result);

            riskAssessmentRepository.save(RiskAssessment.builder()
                    .report(report)
                    .category(result.getCategory())
                    .indicator(result.getIndicator())
                    .score(result.getScore())
                    .notes(result.getNotes())
                    .build());

            weightedSum += result.getScore() * strategy.getWeight();
            weightTotal += strategy.getWeight();
        }

        double overallScore = weightTotal > 0 ? round2(weightedSum / weightTotal) : 0.0;
        String summary = buildRiskSummary(overallScore, results);

        return new RiskOutcome(results, overallScore, summary);
    }

    /** category results + weighted overall score + a short auto-generated blurb. */
    public record RiskOutcome(List<RiskCategoryResult> results, double overallScore, String summary) {}

    private String buildRiskSummary(double overallScore, List<RiskCategoryResult> results) {
        String tier = overallScore >= 70 ? "HIGH" : overallScore >= 40 ? "MODERATE" : "LOW";
        String topConcerns = results.stream()
                .sorted((a, b) -> Double.compare(b.getScore(), a.getScore()))
                .limit(2)
                .map(RiskCategoryResult::getIndicator)
                .collect(Collectors.joining("; "));

        return String.format("Overall risk score %.1f/100 (%s). Leading concerns: %s.",
                overallScore, tier, topConcerns);
    }

    private double round2(double value) {
        return Math.round(value * 100.0) / 100.0;
    }

    private Property getProperty(Long id) {
        return propertyRepository.findById(id)
                .orElseThrow(() -> new ExternalDataNotFoundException("Property not found with id: " + id));
    }

    private String currentUserLabel() {
        User user = currentUserOrNull();
        return user != null ? user.getFullName() + " (" + user.getEmail() + ")" : "Unknown";
    }

    private User currentUserOrNull() {
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return principal instanceof User user ? user : null;
    }
}
