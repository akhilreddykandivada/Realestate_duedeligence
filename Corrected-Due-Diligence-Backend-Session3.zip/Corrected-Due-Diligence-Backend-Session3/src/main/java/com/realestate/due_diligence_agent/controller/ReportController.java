package com.realestate.due_diligence_agent.controller;

import com.realestate.due_diligence_agent.dto.ReportResponse;
import com.realestate.due_diligence_agent.dto.RiskAssessmentResponse;
import com.realestate.due_diligence_agent.service.ReportService;
import com.realestate.due_diligence_agent.service.RiskAssessmentService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/** Property-scoped report endpoints. See ReportLookupController for /api/reports/*. */
@RestController
@RequestMapping("/api/properties/{id}")
@RequiredArgsConstructor
public class ReportController {

    private final ReportService reportService;
    private final RiskAssessmentService riskAssessmentService;

    /**
     * Runs the FULL report pipeline: gather due-diligence data -> risk
     * assessment -> comparable listings -> timeline -> executive summary
     * -> PDF/Excel export. Returns the complete report immediately
     * (synchronous) - status will be COMPLETED, or FAILED with a reason
     * if something went wrong partway through.
     */
    @PostMapping("/reports")
    public ResponseEntity<ReportResponse> generateReport(@PathVariable Long id) {
        ReportResponse response = reportService.generateReport(id);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    /**
     * Standalone quick-run: just the six risk strategies, its own
     * lightweight report, no comparables/timeline/PDF/Excel. Kept
     * separate from the full pipeline above for a fast risk-only check.
     */
    @PostMapping("/risk-assessment")
    public ResponseEntity<RiskAssessmentResponse> runRiskAssessment(@PathVariable Long id) {
        return ResponseEntity.ok(riskAssessmentService.runRiskAssessment(id));
    }
}
