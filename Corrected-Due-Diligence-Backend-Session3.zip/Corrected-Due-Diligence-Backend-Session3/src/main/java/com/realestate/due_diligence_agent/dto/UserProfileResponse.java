package com.realestate.due_diligence_agent.dto;

import com.realestate.due_diligence_agent.entity.Role;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;

@Data
@Builder
public class UserProfileResponse {
    private Long id;
    private String fullName;
    private String email;
    private Role role;
    private LocalDateTime createdAt;
    private List<OwnedPropertyResponse> ownedProperties;
    private String token;
}
