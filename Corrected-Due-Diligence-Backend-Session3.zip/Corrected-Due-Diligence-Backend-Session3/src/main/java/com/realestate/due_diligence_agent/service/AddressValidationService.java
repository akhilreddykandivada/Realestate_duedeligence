package com.realestate.due_diligence_agent.service;

import com.realestate.due_diligence_agent.dto.AddressValidationResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatusCode;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.util.retry.Retry;

import java.time.Duration;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class AddressValidationService {
    private final WebClient.Builder webClientBuilder;

    @Value("${google.geocoding.api-key}")
    private String apiKey;

    @Value("${google.geocoding.base-url}")
    private String googleBaseUrl;

    @Value("${google.geocoding.retry.max-attempts:3}")
    private long maxAttempts;

    @Value("${google.geocoding.retry.delay-ms:500}")
    private long retryDelayMs;

    @Value("${geocoding.fallback.enabled:true}")
    private boolean fallbackEnabled;

    @Value("${geocoding.fallback.base-url:https://nominatim.openstreetmap.org/search}")
    private String fallbackBaseUrl;

    public AddressValidationResponse validate(String address) {
        String normalizedAddress = basicValidate(address);

        if (!StringUtils.hasText(apiKey)
                || apiKey.startsWith("YOUR_GOOGLE_")) {
            if (fallbackEnabled) {
                return validateWithNominatim(normalizedAddress,
                        "Google key is not configured; free prototype geocoding was used.");
            }
            throw new IllegalStateException(
                    "Google Geocoding API key is not configured. Set GOOGLE_MAPS_API_KEY."
            );
        }

        try {
            AddressValidationResponse googleResult = callGoogle(normalizedAddress);
            if (googleResult.isValid()) {
                return googleResult;
            }

            // Google's Demo Key can be rejected for billing/project reasons.
            // Keep the Google integration intact, but use the mentor-documented
            // free Nominatim alternative so the prototype can still return real coordinates.
            if (fallbackEnabled && isGoogleAccessProblem(googleResult.getMessage())) {
                return validateWithNominatim(normalizedAddress,
                        "Google Geocoding could not be used for this key; verified with the free prototype geocoder.");
            }
            return googleResult;
        } catch (RuntimeException exception) {
            if (fallbackEnabled) {
                return validateWithNominatim(normalizedAddress,
                        "Google Geocoding was unavailable; verified with the free prototype geocoder.");
            }
            throw exception;
        }
    }

    private AddressValidationResponse callGoogle(String address) {
        Map<String, Object> response = webClientBuilder
                .baseUrl(googleBaseUrl)
                .build()
                .get()
                .uri(uriBuilder -> uriBuilder
                        .queryParam("address", address)
                        .queryParam("key", apiKey)
                        .build())
                .retrieve()
                .onStatus(HttpStatusCode::isError, status -> status.createException())
                .bodyToMono(Map.class)
                .retryWhen(
                        Retry.backoff(Math.max(1, maxAttempts - 1),
                                        Duration.ofMillis(Math.max(100, retryDelayMs)))
                                .filter(this::isRetryable)
                                .onRetryExhaustedThrow((spec, signal) ->
                                        new IllegalStateException(
                                                "Google Geocoding service is temporarily unavailable.",
                                                signal.failure())))
                .block();

        if (response == null) {
            throw new IllegalStateException("No response received from Google Geocoding service.");
        }

        String status = String.valueOf(response.get("status"));
        if (!"OK".equalsIgnoreCase(status)) {
            String message = String.valueOf(response.getOrDefault(
                    "error_message", "Address could not be verified by Google."));
            return AddressValidationResponse.builder()
                    .valid(false)
                    .provider("Google Geocoding API")
                    .message(message)
                    .build();
        }

        List<Map<String, Object>> results = (List<Map<String, Object>>) response.get("results");
        if (results == null || results.isEmpty()) {
            return AddressValidationResponse.builder()
                    .valid(false)
                    .provider("Google Geocoding API")
                    .message("No matching address was found by Google.")
                    .build();
        }

        Map<String, Object> firstResult = results.get(0);
        Map<String, Object> geometry = (Map<String, Object>) firstResult.get("geometry");
        Map<String, Object> location = geometry == null ? null :
                (Map<String, Object>) geometry.get("location");

        if (location == null) {
            return AddressValidationResponse.builder()
                    .valid(false)
                    .provider("Google Geocoding API")
                    .message("Google returned an address without coordinates.")
                    .build();
        }

        return AddressValidationResponse.builder()
                .valid(true)
                .cleanAddress(String.valueOf(firstResult.get("formatted_address")))
                .latitude(toDouble(location.get("lat")))
                .longitude(toDouble(location.get("lng")))
                .provider("Google Geocoding API")
                .message("Address verified successfully by Google.")
                .build();
    }

    private AddressValidationResponse validateWithNominatim(String address, String reason) {
        List<Map<String, Object>> results = webClientBuilder
                .baseUrl(fallbackBaseUrl)
                .defaultHeader("User-Agent", "RealEstateDueDiligenceAgent/1.0 student-prototype")
                .build()
                .get()
                .uri(uriBuilder -> uriBuilder
                        .queryParam("q", address)
                        .queryParam("format", "jsonv2")
                        .queryParam("limit", 1)
                        .queryParam("addressdetails", 1)
                        .build())
                .retrieve()
                .bodyToMono(List.class)
                .retryWhen(Retry.backoff(2, Duration.ofMillis(500)))
                .block();

        if (results == null || results.isEmpty()) {
            return AddressValidationResponse.builder()
                    .valid(false)
                    .provider("Nominatim (OpenStreetMap fallback)")
                    .message("No matching address was found. " + reason)
                    .build();
        }

        Map<String, Object> first = results.get(0);
        Double latitude = toDouble(first.get("lat"));
        Double longitude = toDouble(first.get("lon"));
        String displayName = String.valueOf(first.get("display_name"));

        return AddressValidationResponse.builder()
                .valid(latitude != null && longitude != null)
                .cleanAddress(displayName)
                .latitude(latitude)
                .longitude(longitude)
                .provider("Nominatim (OpenStreetMap fallback)")
                .message(reason + " Coordinates returned from the free prototype geocoder.")
                .build();
    }

    private String basicValidate(String address) {
        if (!StringUtils.hasText(address)) {
            throw new IllegalArgumentException("Address must not be blank.");
        }
        String normalized = address.trim().replaceAll("\\s+", " ");
        if (normalized.length() < 5) {
            throw new IllegalArgumentException("Address is too short to validate.");
        }
        if (!normalized.matches(".*[A-Za-z].*")) {
            throw new IllegalArgumentException("Address should contain a place or street name.");
        }
        return normalized;
    }

    private boolean isGoogleAccessProblem(String message) {
        if (message == null) return false;
        String value = message.toLowerCase();
        return value.contains("billing")
                || value.contains("request_denied")
                || value.contains("api key")
                || value.contains("not authorized")
                || value.contains("project");
    }

    private boolean isRetryable(Throwable throwable) {
        return !(throwable instanceof IllegalArgumentException)
                && !(throwable instanceof IllegalStateException);
    }

    private Double toDouble(Object value) {
        if (value instanceof Number number) return number.doubleValue();
        try {
            return value == null ? null : Double.parseDouble(String.valueOf(value));
        } catch (NumberFormatException ignored) {
            return null;
        }
    }
}
