package com.realestate.due_diligence_agent.service;

import com.realestate.due_diligence_agent.dto.UtilityInformationRequest;
import com.realestate.due_diligence_agent.entity.Property;
import com.realestate.due_diligence_agent.entity.User;
import com.realestate.due_diligence_agent.entity.UtilityInformation;
import com.realestate.due_diligence_agent.integration.ExternalDataNotFoundException;
import com.realestate.due_diligence_agent.repository.PropertyRepository;
import com.realestate.due_diligence_agent.repository.UtilityInformationRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Full CRUD under /api/properties/{id}/utilities. Unlike the other new
 * modules this isn't backed by an external API - it's manually entered by
 * whoever is logged in, which is exactly what "source" records: it's
 * always set to the current user's full name automatically (never taken
 * from the request body), which is what makes it "Manual Entry" data
 * traceable to a specific person rather than a free-text field someone
 * could fake.
 */
@Service
@RequiredArgsConstructor
public class UtilityInformationService {

    private final PropertyRepository propertyRepository;
    private final UtilityInformationRepository utilityInformationRepository;

    @Transactional
    public UtilityInformation create(Long propertyId, UtilityInformationRequest request) {
        Property property = getProperty(propertyId);

        UtilityInformation utility = UtilityInformation.builder()
                .property(property)
                .utilityType(request.getUtilityType())
                .providerName(request.getProviderName())
                .accountNumber(request.getAccountNumber())
                .monthlyCost(request.getMonthlyCost())
                .notes(request.getNotes())
                .source(currentUserLabel())
                .build();

        return utilityInformationRepository.save(utility);
    }

    @Transactional(readOnly = true)
    public List<UtilityInformation> list(Long propertyId) {
        getProperty(propertyId);
        return utilityInformationRepository.findByPropertyId(propertyId);
    }

    @Transactional
    public UtilityInformation update(Long propertyId, Long utilityId, UtilityInformationRequest request) {
        UtilityInformation utility = getUtility(propertyId, utilityId);

        utility.setUtilityType(request.getUtilityType());
        utility.setProviderName(request.getProviderName());
        utility.setAccountNumber(request.getAccountNumber());
        utility.setMonthlyCost(request.getMonthlyCost());
        utility.setNotes(request.getNotes());
        // source intentionally left as the original creator - editing doesn't
        // reassign "who entered this", it just updates the values.

        return utilityInformationRepository.save(utility);
    }

    @Transactional
    public void delete(Long propertyId, Long utilityId) {
        UtilityInformation utility = getUtility(propertyId, utilityId);
        utilityInformationRepository.delete(utility);
    }

    private UtilityInformation getUtility(Long propertyId, Long utilityId) {
        return utilityInformationRepository.findByIdAndPropertyId(utilityId, propertyId)
                .orElseThrow(() -> new ExternalDataNotFoundException(
                        "Utility record " + utilityId + " not found for property " + propertyId + "."));
    }

    private Property getProperty(Long id) {
        return propertyRepository.findById(id)
                .orElseThrow(() -> new ExternalDataNotFoundException("Property not found with id: " + id));
    }

    private String currentUserLabel() {
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        if (principal instanceof User user) {
            return user.getFullName();
        }
        return "Manual Entry";
    }
}
