package com.realestate.due_diligence_agent.dto;

import lombok.*;

@Getter @Setter @Builder @NoArgsConstructor @AllArgsConstructor
public class RiskCategoryResult {
    private String category;
    private String indicator;
    private Double score;   // 0-100, higher = riskier
    private String notes;
}
