package com.realestate.due_diligence_agent.integration.elevation;

import com.fasterxml.jackson.databind.JsonNode;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatusCode;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.util.retry.Retry;

import java.time.Duration;

/**
 * FEMA's NFHL doesn't return ground elevation, so a separate source is
 * needed for it. I don't have a record of "the additional elevation source
 * discussed during the session", so this defaults to the USGS Elevation
 * Point Query Service (EPQS) - a free, no-key, no-billing federal API that
 * returns ground elevation for any US lat/lng. If your mentor specified a
 * different provider, only ELEVATION_API_BASE_URL needs to change - no
 * code edits required, as long as the replacement also returns a plain
 * numeric elevation value somewhere in its JSON body.
 */
@Component
@RequiredArgsConstructor
public class ElevationClient {

    private final WebClient.Builder webClientBuilder;
    private WebClient webClient;

    @Value("${elevation.base-url:https://epqs.nationalmap.gov/v1/json}")
    private String baseUrl;
    @Value("${elevation.units:Feet}")
    private String units;

    @PostConstruct
    private void init() {
        // No baseUrl() here - the full path is built per-call below since
        // this service has no separate "path" concept beyond the base URL.
        this.webClient = webClientBuilder.build();
    }

    /** Returns ground elevation in the configured units, or null if unavailable. */
    public Double getElevation(double latitude, double longitude) {
        try {
            JsonNode body = webClient
                    .get()
                    .uri(baseUrl + "?x=" + longitude + "&y=" + latitude + "&units=" + units + "&wkid=4326&includeDate=false")
                    .retrieve()
                    .onStatus(HttpStatusCode::isError, status -> status.createException())
                    .bodyToMono(JsonNode.class)
                    .retryWhen(Retry.backoff(2, Duration.ofMillis(500))
                            .filter(t -> !(t instanceof IllegalArgumentException)))
                    .block();

            if (body == null) return null;

            if (body.has("value") && body.get("value").isNumber()) {
                return body.get("value").asDouble();
            }
            JsonNode nested = body.path("USGS_Elevation_Point_Query_Service").path("Elevation_Query").path("Elevation");
            if (nested.isNumber()) return nested.asDouble();

            return null;
        } catch (Exception ex) {
            // Elevation is a supplementary field, not the reason the whole flood-zone
            // lookup should fail - swallow and let FloodZoneData.groundElevation stay null.
            return null;
        }
    }
}
