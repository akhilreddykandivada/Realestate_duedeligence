package com.realestate.due_diligence_agent.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.*;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class UtilityInformationRequest {

    @NotBlank(message = "Utility type is required")
    private String utilityType;

    private String providerName;
    private String accountNumber;
    private Double monthlyCost;
    private String notes;
}
