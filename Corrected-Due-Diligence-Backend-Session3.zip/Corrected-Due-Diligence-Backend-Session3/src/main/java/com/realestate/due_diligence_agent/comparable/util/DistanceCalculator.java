package com.realestate.due_diligence_agent.comparable.util;

/**
 * Kept as a standalone static utility (no Spring dependencies) so it can
 * be unit tested in isolation without a Spring context.
 */
public final class DistanceCalculator {

    private static final double EARTH_RADIUS_MILES = 3958.8;

    private DistanceCalculator() {}

    /** Haversine formula - great-circle distance in miles between two lat/lng points. */
    public static double calculateMiles(double lat1, double lon1, double lat2, double lon2) {
        double dLat = Math.toRadians(lat2 - lat1);
        double dLon = Math.toRadians(lon2 - lon1);

        double a = Math.sin(dLat / 2) * Math.sin(dLat / 2)
                + Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2))
                * Math.sin(dLon / 2) * Math.sin(dLon / 2);

        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return EARTH_RADIUS_MILES * c;
    }
}
