package com.realestate.due_diligence_agent.service;

import com.realestate.due_diligence_agent.dto.DueDiligenceAggregateResponse;
import com.realestate.due_diligence_agent.dto.SectionResult;
import com.realestate.due_diligence_agent.entity.*;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import java.util.function.Supplier;

/**
 * GET /api/properties/{id}/due-diligence - runs all 7 sections in parallel
 * via CompletableFuture. A failure in any one section is caught and turned
 * into a SectionResult.failed(...) rather than propagating - the endpoint
 * always returns 200 with all 7 keys present, each independently
 * SUCCESS or FAILED.
 */
@Service
@RequiredArgsConstructor
public class DueDiligenceAggregationService {

    private final DueDiligenceService dueDiligenceService;
    private final FloodZoneService floodZoneService;
    private final PermitService permitService;
    private final EnvironmentalRecordService environmentalRecordService;
    private final UtilityInformationService utilityInformationService;

    @Qualifier("dueDiligenceExecutor")
    private final Executor executor;

    public DueDiligenceAggregateResponse aggregate(Long propertyId) {
        CompletableFuture<SectionResult<List<OwnershipRecord>>> ownershipFuture =
                runAsync(() -> dueDiligenceService.getOwnership(propertyId));

        CompletableFuture<SectionResult<List<TaxHistory>>> taxHistoryFuture =
                runAsync(() -> dueDiligenceService.getTaxHistory(propertyId));

        CompletableFuture<SectionResult<ZoningInformation>> zoningFuture =
                runAsync(() -> dueDiligenceService.getZoning(propertyId));

        CompletableFuture<SectionResult<FloodZoneData>> floodZoneFuture =
                runAsync(() -> floodZoneService.getFloodZone(propertyId));

        CompletableFuture<SectionResult<List<Permit>>> permitsFuture =
                runAsync(() -> permitService.getPermits(propertyId));

        CompletableFuture<SectionResult<List<EnvironmentalRecord>>> environmentalFuture =
                runAsync(() -> environmentalRecordService.getEnvironmentalRecords(propertyId));

        CompletableFuture<SectionResult<List<UtilityInformation>>> utilitiesFuture =
                runAsync(() -> utilityInformationService.list(propertyId));

        CompletableFuture.allOf(ownershipFuture, taxHistoryFuture, zoningFuture, floodZoneFuture,
                permitsFuture, environmentalFuture, utilitiesFuture).join();

        return DueDiligenceAggregateResponse.builder()
                .propertyId(propertyId)
                .ownership(ownershipFuture.join())
                .taxHistory(taxHistoryFuture.join())
                .zoning(zoningFuture.join())
                .floodZone(floodZoneFuture.join())
                .permits(permitsFuture.join())
                .environmental(environmentalFuture.join())
                .utilities(utilitiesFuture.join())
                .build();
    }

    /**
     * Runs the given call on the shared executor and converts any exception
     * into a failed SectionResult instead of letting it fail the future -
     * .handle() sees both outcomes and always produces a normal
     * (non-exceptional) result, so .join() below never throws.
     */
    private <T> CompletableFuture<SectionResult<T>> runAsync(Supplier<T> call) {
        return CompletableFuture.supplyAsync(call, executor)
                .handle((data, throwable) -> throwable == null
                        ? SectionResult.success(data)
                        : SectionResult.<T>failed(rootMessage(throwable)));
    }

    private String rootMessage(Throwable throwable) {
        Throwable cause = throwable;
        while (cause.getCause() != null && cause.getCause() != cause) {
            cause = cause.getCause();
        }
        return cause.getMessage() != null ? cause.getMessage() : cause.getClass().getSimpleName();
    }
}
