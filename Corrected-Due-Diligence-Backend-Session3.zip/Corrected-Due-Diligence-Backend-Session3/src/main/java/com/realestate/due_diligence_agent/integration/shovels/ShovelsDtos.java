package com.realestate.due_diligence_agent.integration.shovels;

import com.fasterxml.jackson.databind.JsonNode;
import lombok.Getter;

import java.util.ArrayList;
import java.util.List;

/**
 * Shovels.ai's /permits/search response. I don't have the exact documented
 * schema (referenced as "shared in earlier emails"), so this reads
 * defensively: the results array is commonly returned under "items" or
 * "permits" or "results" depending on API version - all three are checked.
 * Verify against your actual Shovels docs and adjust the candidate key
 * list in ShovelsDtos.SearchResult.from(...) if none of them match.
 */
public class ShovelsDtos {

    @Getter
    public static class SearchResult {
        private final List<JsonNode> permits = new ArrayList<>();

        public static SearchResult from(JsonNode body) {
            SearchResult result = new SearchResult();
            if (body == null) return result;
            for (String key : new String[]{"items", "permits", "results", "data"}) {
                if (body.has(key) && body.get(key).isArray()) {
                    body.get(key).forEach(result.permits::add);
                    return result;
                }
            }
            if (body.isArray()) {
                body.forEach(result.permits::add);
            }
            return result;
        }
    }
}
