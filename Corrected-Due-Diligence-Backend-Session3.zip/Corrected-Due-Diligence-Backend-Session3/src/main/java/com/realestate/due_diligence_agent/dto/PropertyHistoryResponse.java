package com.realestate.due_diligence_agent.dto;

import com.realestate.due_diligence_agent.entity.PropertyHistory;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDate;

@Data
@Builder
public class PropertyHistoryResponse {

    private Long id;
    private Long propertyId;
    private LocalDate eventDate;
    private String eventType;
    private String description;
    private String source;

    public static PropertyHistoryResponse from(PropertyHistory history) {
        return PropertyHistoryResponse.builder()
                .id(history.getId())
                .propertyId(history.getProperty().getId())
                .eventDate(history.getEventDate())
                .eventType(history.getEventType())
                .description(history.getDescription())
                .source(history.getSource())
                .build();
    }
}
