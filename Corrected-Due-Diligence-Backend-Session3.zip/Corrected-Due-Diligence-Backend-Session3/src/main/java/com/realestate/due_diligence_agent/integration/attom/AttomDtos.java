package com.realestate.due_diligence_agent.integration.attom;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

/** DTOs mirror the common ATTOM Property API response envelope while allowing
 * provider-side fields to evolve without breaking the application. */
public final class AttomDtos {
    private AttomDtos() {}

    @Data @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Response<T> {
        private Status status;
        private List<T> property;
    }

    @Data @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Status {
        private String version;
        private Integer code;
        private String msg;
        private Integer total;
        private Integer returned;
    }

    @Data @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Property {
        private Identifier identifier;
        private Address address;
        private Location location;
        private Assessment assessment;
        private List<Owner> owner;
    }

    @Data @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Identifier {
        @JsonProperty("Id") private String id;
        private Long attomId;
        private String apn;
        private String fips;
    }

    @Data @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Address {
        private String line1;
        private String line2;
        private String locality;
        private String countrySubd;
        private String postal1;
        private String oneLine;
    }

    @Data @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Location {
        private Double latitude;
        private Double longitude;
        private String accuracy;
    }

    @Data @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Assessment {
        private Integer taxyear;
        private Double assessedValue;
        private Double taxAmount;
        private Tax tax;
        private Market market;
        private Assessed assessed;
        private Appraised appraised;
        private Owner owner;
    }

    @Data @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Assessed {
        private Double assdTtlValue;
    }

    @Data @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Appraised {
        private Double apprTtlValue;
    }

    @Data @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Tax {
        private Integer taxYear;
        private Double amount;
        @JsonProperty("taxAmt")
        private Double taxAmt;
    }

    @Data @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Market {
        private Double mktTtlValue;
        private Double mktLandValue;
        private Double mktImprValue;
    }

    @Data @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Owner {
        private String fullName;
        private String firstNameAndMi;
        private String lastName;
        private String companyName;
        private String corporateIndicator;
        private String ownerOccupied;
        private String absenteeOwnerStatus;
        private String mailingAddressOneLine;
    }

    @Data @JsonIgnoreProperties(ignoreUnknown = true)
    public static class SaleHistory {
        private String saleTransDate;
        private Double saleAmt;
    }
}
