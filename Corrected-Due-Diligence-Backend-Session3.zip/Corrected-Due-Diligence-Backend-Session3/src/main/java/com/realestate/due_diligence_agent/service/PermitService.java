package com.realestate.due_diligence_agent.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.realestate.due_diligence_agent.entity.Permit;
import com.realestate.due_diligence_agent.entity.Property;
import com.realestate.due_diligence_agent.integration.ExternalDataNotFoundException;
import com.realestate.due_diligence_agent.integration.shovels.ShovelsClient;
import com.realestate.due_diligence_agent.integration.shovels.ShovelsDtos;
import com.realestate.due_diligence_agent.repository.PermitRepository;
import com.realestate.due_diligence_agent.repository.PropertyRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * Database-first, same as DueDiligenceService - Shovels' free trial has a
 * SHARED 250-request cap, so /permits/search is only ever called here, and
 * only when the database has nothing yet for this property.
 */
@Service
@RequiredArgsConstructor
public class PermitService {

    private final PropertyRepository propertyRepository;
    private final PermitRepository permitRepository;
    private final ShovelsClient shovelsClient;

    @Transactional
    public List<Permit> getPermits(Long propertyId) {
        Property property = getProperty(propertyId);

        List<Permit> existing = permitRepository.findByPropertyId(propertyId);
        if (!existing.isEmpty()) return existing;

        ShovelsDtos.SearchResult result = shovelsClient.search(
                null, property.getAddress(), (LocalDate) null, (LocalDate) null, property.getType());

        if (result.getPermits().isEmpty()) {
            throw new ExternalDataNotFoundException("Shovels returned no permit records for property " + propertyId + ".");
        }

        List<Permit> permits = new ArrayList<>();
        for (JsonNode item : result.getPermits()) {
            permits.add(Permit.builder()
                    .property(property)
                    .permitNumber(find(item, "permit_number", "permit_num", "permit_no", "id"))
                    .permitType(find(item, "permit_type", "type", "category"))
                    .status(find(item, "status", "permit_status"))
                    .issueDate(findDate(item, "issue_date", "issued_date", "filed_date"))
                    .finalDate(findDate(item, "final_date", "finalized_date", "completed_date"))
                    .valuation(findDouble(item, "valuation", "value", "job_value"))
                    .description(find(item, "description", "work_description", "summary"))
                    .source("SHOVELS")
                    .build());
        }
        return permitRepository.saveAll(permits);
    }

    private Property getProperty(Long id) {
        return propertyRepository.findById(id)
                .orElseThrow(() -> new ExternalDataNotFoundException("Property not found with id: " + id));
    }

    private String find(JsonNode item, String... keys) {
        for (String key : keys) {
            JsonNode value = item.get(key);
            if (value != null && !value.isNull() && StringUtils.hasText(value.asText())) return value.asText();
        }
        return null;
    }

    private Double findDouble(JsonNode item, String... keys) {
        String text = find(item, keys);
        if (text == null) return null;
        try { return Double.parseDouble(text); } catch (NumberFormatException e) { return null; }
    }

    private LocalDate findDate(JsonNode item, String... keys) {
        String text = find(item, keys);
        if (text == null) return null;
        try { return LocalDate.parse(text.length() > 10 ? text.substring(0, 10) : text); }
        catch (Exception e) { return null; }
    }
}
