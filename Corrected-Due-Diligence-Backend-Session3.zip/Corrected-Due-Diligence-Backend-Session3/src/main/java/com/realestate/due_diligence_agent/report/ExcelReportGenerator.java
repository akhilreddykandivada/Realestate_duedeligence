package com.realestate.due_diligence_agent.report;

import com.realestate.due_diligence_agent.comparable.entity.ComparableListing;
import com.realestate.due_diligence_agent.dto.TimelineEntry;
import com.realestate.due_diligence_agent.entity.Property;
import com.realestate.due_diligence_agent.entity.Report;
import com.realestate.due_diligence_agent.entity.RiskAssessment;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Component;

import java.io.ByteArrayOutputStream;
import java.util.List;

/** 4 sheets: Summary, Risk Assessment, Comparable Listings, Timeline. */
@Component
public class ExcelReportGenerator {

    public byte[] generate(Property property, Report report, List<RiskAssessment> riskAssessments,
                            List<TimelineEntry> timeline, List<ComparableListing> comparables) {
        try (XSSFWorkbook workbook = new XSSFWorkbook();
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {

            CellStyle headerStyle = workbook.createCellStyle();
            Font headerFont = workbook.createFont();
            headerFont.setBold(true);
            headerStyle.setFont(headerFont);

            buildSummarySheet(workbook, headerStyle, property, report);
            buildRiskSheet(workbook, headerStyle, riskAssessments);
            buildComparablesSheet(workbook, headerStyle, comparables);
            buildTimelineSheet(workbook, headerStyle, timeline);

            workbook.write(out);
            return out.toByteArray();
        } catch (Exception e) {
            throw new ReportGenerationException("Unable to generate Excel report", e);
        }
    }

    private void buildSummarySheet(XSSFWorkbook workbook, CellStyle headerStyle, Property property, Report report) {
        Sheet sheet = workbook.createSheet("Summary");
        int r = 0;
        writeLabelValueRow(sheet, r++, headerStyle, "Property Address", property.getAddress());
        writeLabelValueRow(sheet, r++, headerStyle, "Location", property.getLocation());
        writeLabelValueRow(sheet, r++, headerStyle, "Overall Risk Score",
                report.getRiskScore() != null ? report.getRiskScore().toString() : "N/A");
        writeLabelValueRow(sheet, r++, headerStyle, "Status",
                report.getStatus() != null ? report.getStatus().toString() : "N/A");
        writeLabelValueRow(sheet, r, headerStyle, "Executive Summary", safe(report.getExecutiveSummary()));
        autosize(sheet, 2);
    }

    private void buildRiskSheet(XSSFWorkbook workbook, CellStyle headerStyle, List<RiskAssessment> riskAssessments) {
        Sheet sheet = workbook.createSheet("Risk Assessment");
        writeHeaderRow(sheet, headerStyle, "Category", "Score", "Indicator", "Notes");
        int row = 1;
        if (riskAssessments != null) {
            for (RiskAssessment ra : riskAssessments) {
                Row r = sheet.createRow(row++);
                r.createCell(0).setCellValue(safe(ra.getCategory()));
                r.createCell(1).setCellValue(ra.getScore() != null ? ra.getScore() : 0);
                r.createCell(2).setCellValue(safe(ra.getIndicator()));
                r.createCell(3).setCellValue(safe(ra.getNotes()));
            }
        }
        autosize(sheet, 4);
    }

    private void buildComparablesSheet(XSSFWorkbook workbook, CellStyle headerStyle, List<ComparableListing> comparables) {
        Sheet sheet = workbook.createSheet("Comparable Listings");
        writeHeaderRow(sheet, headerStyle, "Address", "Price", "Distance (mi)", "Listed Date", "Square Feet");
        int row = 1;
        if (comparables != null) {
            for (ComparableListing comp : comparables) {
                Row r = sheet.createRow(row++);
                r.createCell(0).setCellValue(safe(comp.getComparableAddress()));
                r.createCell(1).setCellValue(comp.getPrice() != null ? comp.getPrice() : 0);
                r.createCell(2).setCellValue(comp.getDistanceMiles() != null ? comp.getDistanceMiles() : 0);
                r.createCell(3).setCellValue(comp.getListedDate() != null ? comp.getListedDate().toString() : "");
                r.createCell(4).setCellValue(comp.getSquareFeet() != null ? comp.getSquareFeet() : 0);
            }
        }
        autosize(sheet, 5);
    }

    private void buildTimelineSheet(XSSFWorkbook workbook, CellStyle headerStyle, List<TimelineEntry> timeline) {
        Sheet sheet = workbook.createSheet("Timeline");
        writeHeaderRow(sheet, headerStyle, "Date", "Label", "Description");
        int row = 1;
        if (timeline != null) {
            for (TimelineEntry entry : timeline) {
                Row r = sheet.createRow(row++);
                r.createCell(0).setCellValue(entry.getDate() != null ? entry.getDate().toString() : "");
                r.createCell(1).setCellValue(safe(entry.getLabel()));
                r.createCell(2).setCellValue(safe(entry.getDescription()));
            }
        }
        autosize(sheet, 3);
    }

    private void writeHeaderRow(Sheet sheet, CellStyle headerStyle, String... columns) {
        Row header = sheet.createRow(0);
        for (int i = 0; i < columns.length; i++) {
            Cell cell = header.createCell(i);
            cell.setCellValue(columns[i]);
            cell.setCellStyle(headerStyle);
        }
    }

    private void writeLabelValueRow(Sheet sheet, int rowIdx, CellStyle headerStyle, String label, String value) {
        Row row = sheet.createRow(rowIdx);
        Cell labelCell = row.createCell(0);
        labelCell.setCellValue(label);
        labelCell.setCellStyle(headerStyle);
        row.createCell(1).setCellValue(value != null ? value : "N/A");
    }

    private void autosize(Sheet sheet, int columns) {
        for (int i = 0; i < columns; i++) sheet.autoSizeColumn(i);
    }

    private String safe(String value) {
        return value != null ? value : "N/A";
    }
}
