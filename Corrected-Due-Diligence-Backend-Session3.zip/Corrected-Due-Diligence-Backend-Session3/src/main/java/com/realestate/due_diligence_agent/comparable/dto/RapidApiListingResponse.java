package com.realestate.due_diligence_agent.comparable.dto;

import com.fasterxml.jackson.databind.JsonNode;
import lombok.Getter;

import java.util.ArrayList;
import java.util.List;

/**
 * Wrapper for a RapidAPI real-estate-listings response.
 *
 * IMPORTANT: I do not have a RapidAPI account/subscription, so I cannot
 * inspect a real response - per the task spec's own instruction ("do not
 * assume the response fields"), guessing an exact rigid structure would be
 * dishonest. Instead this reads defensively: the listings array is looked
 * for under several common top-level keys used by popular RapidAPI
 * real-estate listing APIs (Realty in US, Realtor, Zillow-com1, etc).
 *
 * ACTION NEEDED FROM YOU: once you've subscribed and tested the real
 * endpoint in RapidAPI's console, confirm the actual key holding the
 * listings array and add it to CANDIDATE_ARRAY_KEYS below if it isn't
 * already covered, then verify the per-field lookups in
 * ComparableListingService.mapListing(...) match your API's real field
 * names (price, address, list date, lat/lng, sqft).
 */
@Getter
public class RapidApiListingResponse {

    private static final String[] CANDIDATE_ARRAY_KEYS = {
            "results", "data", "properties", "listings", "homes", "hits"
    };

    private final List<JsonNode> listings = new ArrayList<>();

    public static RapidApiListingResponse from(JsonNode body) {
        RapidApiListingResponse response = new RapidApiListingResponse();
        if (body == null) return response;

        for (String key : CANDIDATE_ARRAY_KEYS) {
            JsonNode node = body.path(key);
            if (node.isArray()) {
                node.forEach(response.listings::add);
                return response;
            }
            // Some APIs nest one level deeper, e.g. {"data": {"results": [...]}}
            if (node.isObject()) {
                for (String nestedKey : CANDIDATE_ARRAY_KEYS) {
                    JsonNode nested = node.path(nestedKey);
                    if (nested.isArray()) {
                        nested.forEach(response.listings::add);
                        return response;
                    }
                }
            }
        }
        if (body.isArray()) {
            body.forEach(response.listings::add);
        }
        return response;
    }
}
