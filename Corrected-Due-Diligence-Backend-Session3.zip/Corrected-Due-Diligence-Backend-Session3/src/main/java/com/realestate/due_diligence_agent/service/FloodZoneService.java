package com.realestate.due_diligence_agent.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.realestate.due_diligence_agent.entity.FloodZoneData;
import com.realestate.due_diligence_agent.entity.Property;
import com.realestate.due_diligence_agent.integration.ExternalDataNotFoundException;
import com.realestate.due_diligence_agent.integration.elevation.ElevationClient;
import com.realestate.due_diligence_agent.integration.fema.FemaDtos;
import com.realestate.due_diligence_agent.integration.fema.FemaNfhlClient;
import com.realestate.due_diligence_agent.repository.FloodZoneDataRepository;
import com.realestate.due_diligence_agent.repository.PropertyRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class FloodZoneService {

    private final PropertyRepository propertyRepository;
    private final FloodZoneDataRepository floodZoneDataRepository;
    private final FemaNfhlClient femaNfhlClient;
    private final ElevationClient elevationClient;

    @Transactional
    public FloodZoneData getFloodZone(Long propertyId) {
        Property property = getProperty(propertyId);

        Optional<FloodZoneData> existing = floodZoneDataRepository.findByPropertyId(propertyId);
        if (existing.isPresent()) return existing.get();

        if (property.getLatitude() == null || property.getLongitude() == null) {
            throw new ExternalDataNotFoundException(
                    "Property " + propertyId + " has no latitude/longitude on file - run address validation for it first.");
        }

        FemaDtos.QueryResult zoneResult = femaNfhlClient.queryFloodHazardZone(property.getLatitude(), property.getLongitude());
        if (zoneResult.isEmpty()) {
            throw new ExternalDataNotFoundException("FEMA NFHL has no flood hazard zone on file for property " + propertyId + ".");
        }
        JsonNode zoneFields = zoneResult.first();

        FemaDtos.QueryResult panelResult = femaNfhlClient.queryFirmPanel(property.getLatitude(), property.getLongitude());
        JsonNode panelFields = panelResult.isEmpty() ? null : panelResult.first();

        String floodZone = find(zoneFields, "FLD_ZONE", "FLOOD_ZONE", "ZONE");
        Double baseFloodElevation = findDouble(zoneFields, "STATIC_BFE", "BASE_FLOOD_ELEVATION", "BFE");
        String firmPanelNumber = panelFields != null ? find(panelFields, "FIRM_PAN", "PANEL", "DFIRM_ID") : null;
        LocalDate panelEffectiveDate = panelFields != null ? findDate(panelFields, "EFF_DATE", "EFFECTIVE_DATE") : null;

        Double groundElevation = elevationClient.getElevation(property.getLatitude(), property.getLongitude());

        FloodZoneData floodZoneData = FloodZoneData.builder()
                .property(property)
                .floodZone(floodZone)
                .floodRiskRating(rateRisk(floodZone))
                .firmPanelNumber(firmPanelNumber)
                .panelEffectiveDate(panelEffectiveDate)
                .baseFloodElevation(baseFloodElevation)
                .groundElevation(groundElevation)
                .source("FEMA_NFHL")
                .build();

        return floodZoneDataRepository.save(floodZoneData);
    }

    /**
     * FEMA zone codes: A/AE/AH/AO/AR/A99/V/VE = high-risk Special Flood
     * Hazard Area; X (shaded) = moderate; X (unshaded)/C = minimal.
     * This is a simplification for the risk-scoring module downstream -
     * refine against your mentor's exact rating scale if one was given.
     */
    private String rateRisk(String zone) {
        if (!StringUtils.hasText(zone)) return "UNKNOWN";
        String z = zone.toUpperCase(Locale.ROOT);
        if (z.startsWith("V") || z.startsWith("A")) return "HIGH";
        if (z.startsWith("X") || z.startsWith("B")) return "MODERATE";
        if (z.startsWith("C") || z.equals("D")) return "MINIMAL";
        return "UNKNOWN";
    }

    private Property getProperty(Long id) {
        return propertyRepository.findById(id)
                .orElseThrow(() -> new ExternalDataNotFoundException("Property not found with id: " + id));
    }

    private String find(JsonNode fields, String... keys) {
        if (fields == null) return null;
        for (String key : keys) {
            JsonNode value = fields.get(key);
            if (value != null && !value.isNull() && StringUtils.hasText(value.asText())) return value.asText();
        }
        return null;
    }

    private Double findDouble(JsonNode fields, String... keys) {
        String text = find(fields, keys);
        if (text == null) return null;
        try { return Double.parseDouble(text); } catch (NumberFormatException e) { return null; }
    }

    private LocalDate findDate(JsonNode fields, String... keys) {
        String text = find(fields, keys);
        if (text == null) return null;
        try {
            // FEMA commonly returns epoch millis for date fields in ArcGIS JSON.
            long epochMillis = Long.parseLong(text);
            return java.time.Instant.ofEpochMilli(epochMillis).atZone(java.time.ZoneOffset.UTC).toLocalDate();
        } catch (NumberFormatException ignored) {
            for (DateTimeFormatter fmt : new DateTimeFormatter[]{DateTimeFormatter.ISO_LOCAL_DATE}) {
                try { return LocalDate.parse(text, fmt); } catch (Exception ignored2) { /* try next */ }
            }
            return null;
        }
    }
}
