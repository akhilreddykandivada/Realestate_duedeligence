package com.realestate.due_diligence_agent.dto;

import com.realestate.due_diligence_agent.entity.Property;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class OwnedPropertyResponse {
    private Long id;
    private String address;
    private String location;
    private String type;
    private Double latitude;
    private Double longitude;

    public static OwnedPropertyResponse from(Property property) {
        return OwnedPropertyResponse.builder()
                .id(property.getId())
                .address(property.getAddress())
                .location(property.getLocation())
                .type(property.getType())
                .latitude(property.getLatitude())
                .longitude(property.getLongitude())
                .build();
    }
}
