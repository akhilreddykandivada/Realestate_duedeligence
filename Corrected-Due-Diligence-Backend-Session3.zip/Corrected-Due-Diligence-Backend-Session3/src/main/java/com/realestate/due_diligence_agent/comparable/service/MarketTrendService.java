package com.realestate.due_diligence_agent.comparable.service;

import com.realestate.due_diligence_agent.comparable.entity.ComparableListing;
import com.realestate.due_diligence_agent.comparable.repository.ComparableListingRepository;
import com.realestate.due_diligence_agent.integration.ExternalDataNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Works ONLY with comparable listings already saved in the database -
 * never calls RapidAPI itself. Call GET /comparables first (which does
 * the database-first fetch/refresh) if this returns a 404.
 */
@Service
@RequiredArgsConstructor
public class MarketTrendService {

    private final ComparableListingRepository comparableListingRepository;

    @Transactional(readOnly = true)
    public Map<String, Object> getTrends(Long propertyId) {
        List<ComparableListing> listings = comparableListingRepository.findByPropertyId(propertyId);
        if (listings.isEmpty()) {
            throw new ExternalDataNotFoundException(
                    "No comparable listings saved yet for property " + propertyId + " - call GET /comparables first.");
        }

        List<ComparableListing> withPrice = listings.stream().filter(l -> l.getPrice() != null).toList();
        double averagePrice = withPrice.stream().mapToDouble(ComparableListing::getPrice).average().orElse(0);

        List<ComparableListing> withPriceAndSize = withPrice.stream()
                .filter(l -> l.getSquareFeet() != null && l.getSquareFeet() > 0)
                .toList();
        Double averagePricePerSqft = withPriceAndSize.isEmpty() ? null
                : withPriceAndSize.stream().mapToDouble(l -> l.getPrice() / l.getSquareFeet()).average().orElse(0);

        Double recencyWeightedTrend = computeRecencyWeightedAverage(withPrice);

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("propertyId", propertyId);
        result.put("listingCount", listings.size());
        result.put("averagePrice", round2(averagePrice));
        result.put("averagePricePerSquareFoot", averagePricePerSqft != null ? round2(averagePricePerSqft) : null);
        result.put("recencyWeightedAveragePrice", recencyWeightedTrend != null ? round2(recencyWeightedTrend) : null);
        return result;
    }

    /**
     * Recency weighting: more recent listings count more toward the
     * average. Weight decays linearly with age, floored at 0.1 so very
     * old listings still contribute a little rather than being fully
     * discarded - full weight at 0 days old, decaying to the floor by
     * about a year old.
     */
    private Double computeRecencyWeightedAverage(List<ComparableListing> listings) {
        List<ComparableListing> withDateAndPrice = listings.stream()
                .filter(l -> l.getListedDate() != null && l.getPrice() != null)
                .toList();
        if (withDateAndPrice.isEmpty()) return null;

        LocalDate today = LocalDate.now();
        double weightedSum = 0;
        double weightTotal = 0;

        for (ComparableListing listing : withDateAndPrice) {
            long ageDays = Math.max(0, ChronoUnit.DAYS.between(listing.getListedDate(), today));
            double weight = Math.max(0.1, 1.0 - (ageDays / 365.0));
            weightedSum += listing.getPrice() * weight;
            weightTotal += weight;
        }
        return weightTotal > 0 ? weightedSum / weightTotal : null;
    }

    private double round2(double value) {
        return Math.round(value * 100.0) / 100.0;
    }
}
