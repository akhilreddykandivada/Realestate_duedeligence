package com.realestate.due_diligence_agent.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "reports")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Report {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "property_id", nullable = false)
    private Property property;

    /** Full name/email of whoever triggered the report - display label. */
    @Column(name = "requested_by")
    private String requestedBy;

    /** Real FK to the requesting user - needed for GET /api/reports?user={userId} access control. */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "requested_by_user_id")
    private User requestedByUser;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private ReportStatus status;

    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "risk_score")
    private Double riskScore;

    @Column(name = "executive_summary", columnDefinition = "TEXT")
    private String executiveSummary;

    /** JSON-serialized chronological timeline (see PropertyTimelineBuilder). */
    @Column(name = "property_timeline", columnDefinition = "TEXT")
    private String propertyTimeline;

    @Column(name = "pdf_url")
    private String pdfUrl;

    @Column(name = "excel_url")
    private String excelUrl;

    /** Populated only when status = FAILED. */
    @Column(name = "failure_reason", columnDefinition = "TEXT")
    private String failureReason;

    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
        if (this.status == null) this.status = ReportStatus.REQUESTED;
    }
}
