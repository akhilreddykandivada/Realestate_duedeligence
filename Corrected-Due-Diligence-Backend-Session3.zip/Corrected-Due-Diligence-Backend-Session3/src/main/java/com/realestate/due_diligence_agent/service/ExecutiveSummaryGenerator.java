package com.realestate.due_diligence_agent.service;

import com.realestate.due_diligence_agent.comparable.entity.ComparableListing;
import com.realestate.due_diligence_agent.dto.RiskCategoryResult;
import com.realestate.due_diligence_agent.entity.Property;
import org.springframework.stereotype.Component;

import java.util.Comparator;
import java.util.List;

/**
 * Builds a short, readable executive summary from fixed templates filled
 * in with real project data - overall risk score, the leading risk
 * category, and a comparable-listings market snapshot. No AI/LLM call
 * here, per the spec - plain string templates.
 */
@Component
public class ExecutiveSummaryGenerator {

    public String generate(Property property, double overallScore, List<RiskCategoryResult> categories,
                            List<ComparableListing> comparables) {
        StringBuilder summary = new StringBuilder();

        summary.append(String.format(
                "Due diligence for %s indicates an overall risk score of %.1f out of 100 (%s risk). ",
                property.getAddress() != null ? property.getAddress() : "this property",
                overallScore, riskTier(overallScore)));

        if (categories != null && !categories.isEmpty()) {
            RiskCategoryResult topConcern = categories.stream()
                    .max(Comparator.comparing(c -> c.getScore() == null ? 0.0 : c.getScore()))
                    .orElse(null);
            if (topConcern != null) {
                summary.append("The leading factor is ")
                        .append(topConcern.getCategory() != null
                                ? topConcern.getCategory().toLowerCase().replace('_', ' ')
                                : "an unspecified category")
                        .append(": ").append(topConcern.getIndicator()).append(". ");
            }
        } else {
            summary.append("No risk categories were evaluated. ");
        }

        if (comparables != null && !comparables.isEmpty()) {
            double avgPrice = comparables.stream()
                    .filter(c -> c.getPrice() != null)
                    .mapToDouble(ComparableListing::getPrice)
                    .average().orElse(0);
            summary.append(String.format(
                    "Based on %d comparable listing(s) nearby, the average market price is approximately $%,.0f. ",
                    comparables.size(), avgPrice));
        } else {
            summary.append("No comparable listings were available to benchmark market pricing. ");
        }

        summary.append("See the individual risk categories, property timeline, and comparable listings below for full detail.");
        return summary.toString();
    }

    private String riskTier(double score) {
        if (score >= 70) return "high";
        if (score >= 40) return "moderate";
        return "low";
    }
}
