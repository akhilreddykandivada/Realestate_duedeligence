package com.realestate.due_diligence_agent.controller;

import com.realestate.due_diligence_agent.dto.UtilityInformationRequest;
import com.realestate.due_diligence_agent.entity.UtilityInformation;
import com.realestate.due_diligence_agent.service.UtilityInformationService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/properties/{propertyId}/utilities")
@RequiredArgsConstructor
public class UtilityController {

    private final UtilityInformationService utilityInformationService;

    @PostMapping
    public ResponseEntity<UtilityInformation> create(@PathVariable Long propertyId,
                                                       @Valid @RequestBody UtilityInformationRequest request) {
        UtilityInformation created = utilityInformationService.create(propertyId, request);
        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }

    @GetMapping
    public ResponseEntity<List<UtilityInformation>> list(@PathVariable Long propertyId) {
        return ResponseEntity.ok(utilityInformationService.list(propertyId));
    }

    @PutMapping("/{utilityId}")
    public ResponseEntity<UtilityInformation> update(@PathVariable Long propertyId,
                                                       @PathVariable Long utilityId,
                                                       @Valid @RequestBody UtilityInformationRequest request) {
        return ResponseEntity.ok(utilityInformationService.update(propertyId, utilityId, request));
    }

    @DeleteMapping("/{utilityId}")
    public ResponseEntity<Void> delete(@PathVariable Long propertyId, @PathVariable Long utilityId) {
        utilityInformationService.delete(propertyId, utilityId);
        return ResponseEntity.noContent().build();
    }
}
