package com.realestate.due_diligence_agent.service;

import com.realestate.due_diligence_agent.entity.TaxHistory;
import com.realestate.due_diligence_agent.integration.ExternalDataNotFoundException;
import com.realestate.due_diligence_agent.repository.PropertyRepository;
import com.realestate.due_diligence_agent.repository.TaxHistoryRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Reuses existing tax-history data (no new external calls, no new table) -
 * just reshapes it into a year -> assessed value series for charting.
 */
@Service
@RequiredArgsConstructor
public class PropertyValueHistoryService {

    private final PropertyRepository propertyRepository;
    private final TaxHistoryRepository taxHistoryRepository;

    @Transactional(readOnly = true)
    public List<Map<String, Object>> getValueHistory(Long propertyId) {
        if (!propertyRepository.existsById(propertyId)) {
            throw new ExternalDataNotFoundException("Property not found with id: " + propertyId);
        }

        List<TaxHistory> history = taxHistoryRepository.findByPropertyIdOrderByTaxYearDesc(propertyId);

        return history.stream()
                .filter(t -> t.getTaxYear() != null)
                .sorted((a, b) -> a.getTaxYear().compareTo(b.getTaxYear()))
                .map(this::toEntry)
                .toList();
    }

    private Map<String, Object> toEntry(TaxHistory tax) {
        Map<String, Object> entry = new LinkedHashMap<>();
        entry.put("year", tax.getTaxYear());
        entry.put("assessedValue", tax.getAssessedValue());
        return entry;
    }
}
