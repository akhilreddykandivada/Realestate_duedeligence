package com.realestate.due_diligence_agent.service;

import com.realestate.due_diligence_agent.dto.ChangePasswordRequest;
import com.realestate.due_diligence_agent.dto.OwnedPropertyResponse;
import com.realestate.due_diligence_agent.dto.UpdateProfileRequest;
import com.realestate.due_diligence_agent.dto.UserProfileResponse;
import com.realestate.due_diligence_agent.entity.User;
import com.realestate.due_diligence_agent.repository.PropertyRepository;
import com.realestate.due_diligence_agent.repository.UserRepository;
import com.realestate.due_diligence_agent.security.JwtService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class UserService {
    private final UserRepository userRepository;
    private final PropertyRepository propertyRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;

    @Transactional(readOnly = true)
    public UserProfileResponse getProfile(User user) {
        User freshUser = getFreshUser(user.getId());
        return buildProfile(freshUser, null);
    }

    @Transactional
    public UserProfileResponse updateProfile(User user, UpdateProfileRequest request) {
        User freshUser = getFreshUser(user.getId());
        String newEmail = request.getEmail().trim();

        userRepository.findByEmail(newEmail).ifPresent(existing -> {
            if (!existing.getId().equals(freshUser.getId())) {
                throw new RuntimeException("A user with this email already exists");
            }
        });

        freshUser.setFullName(request.getFullName().trim());
        freshUser.setEmail(newEmail);
        User saved = userRepository.save(freshUser);

        String newToken = jwtService.generateToken(saved);
        return buildProfile(saved, newToken);
    }

    @Transactional
    public void changePassword(User user, ChangePasswordRequest request) {
        User freshUser = getFreshUser(user.getId());
        if (!passwordEncoder.matches(request.getCurrentPassword(), freshUser.getPassword())) {
            throw new RuntimeException("Current password is incorrect");
        }
        if (passwordEncoder.matches(request.getNewPassword(), freshUser.getPassword())) {
            throw new RuntimeException("New password must be different from the current password");
        }
        freshUser.setPassword(passwordEncoder.encode(request.getNewPassword()));
        userRepository.save(freshUser);
    }

    @Transactional(readOnly = true)
    public List<OwnedPropertyResponse> getOwnedProperties(User user) {
        getFreshUser(user.getId());
        return propertyRepository.findByOwnerId(user.getId())
                .stream()
                .map(OwnedPropertyResponse::from)
                .toList();
    }

    private User getFreshUser(Long id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Authenticated user no longer exists"));
    }

    private UserProfileResponse buildProfile(User user, String token) {
        return UserProfileResponse.builder()
                .id(user.getId())
                .fullName(user.getFullName())
                .email(user.getEmail())
                .role(user.getRole())
                .createdAt(user.getCreatedAt())
                .ownedProperties(propertyRepository.findByOwnerId(user.getId())
                        .stream().map(OwnedPropertyResponse::from).toList())
                .token(token)
                .build();
    }
}
