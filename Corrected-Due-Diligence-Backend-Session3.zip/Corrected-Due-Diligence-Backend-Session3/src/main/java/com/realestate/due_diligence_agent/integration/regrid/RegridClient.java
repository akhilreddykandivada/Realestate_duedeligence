package com.realestate.due_diligence_agent.integration.regrid;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.realestate.due_diligence_agent.integration.ExternalApiException;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatusCode;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.util.retry.Retry;

import java.time.Duration;

@Component
@RequiredArgsConstructor
public class RegridClient {
    private final WebClient.Builder webClientBuilder;
    private final ObjectMapper objectMapper;

    private WebClient webClient;

    @Value("${regrid.base-url:https://api.regrid.com/v1}")
    private String baseUrl;
    @Value("${regrid.parcel-path:/parcel/lookup}")
    private String parcelPath;
    @Value("${regrid.api-token:}")
    private String apiToken;
    @Value("${regrid.auth-mode:QUERY}")
    private String authMode;
    @Value("${regrid.token-query-param:token}")
    private String tokenQueryParam;
    @Value("${regrid.retry.max-attempts:3}")
    private long maxAttempts;
    @Value("${regrid.retry.delay-ms:600}")
    private long retryDelayMs;

    @PostConstruct
    private void init() {
        this.webClient = webClientBuilder.baseUrl(baseUrl).build();
    }

    public RegridDtos.ParcelLookupResponse lookup(
            Double latitude, Double longitude, String address) {

        if (!StringUtils.hasText(apiToken)) {
            throw new ExternalApiException(
                    "REGRID API token is not configured. Set REGRID_API_TOKEN before using zoning lookup.");
        }

        if (latitude == null || longitude == null) {
            throw new ExternalApiException(
                    "Property coordinates are missing; Regrid parcel lookup requires a location.");
        }

        try {
            JsonNode body = webClient
                    .get()
                    .uri(uriBuilder -> {
                        var builder = uriBuilder.path(parcelPath)
                                .queryParam("lat", latitude)
                                .queryParam("lon", longitude);

                        // Regrid supports token authentication through the query
                        // parameter for the prototype configuration. Bearer mode
                        // remains available through REGRID_AUTH_MODE=BEARER.
                        if ("QUERY".equalsIgnoreCase(authMode)) {
                            builder.queryParam(tokenQueryParam, apiToken);
                        }

                        return builder.build();
                    })
                    .headers(headers -> {
                        if ("BEARER".equalsIgnoreCase(authMode)) {
                            headers.setBearerAuth(apiToken);
                        }
                    })
                    .retrieve()
                    .onStatus(HttpStatusCode::isError, response ->
                            response.bodyToMono(String.class)
                                    .defaultIfEmpty("")
                                    .map(errorBody -> new ExternalApiException(
                                            "REGRID parcel lookup failed with HTTP "
                                                    + response.statusCode().value()
                                                    + (StringUtils.hasText(errorBody)
                                                    ? ": " + errorBody
                                                    : "."))))
                    .bodyToMono(JsonNode.class)
                    .retryWhen(Retry.backoff(
                                    Math.max(1, maxAttempts - 1),
                                    Duration.ofMillis(Math.max(100, retryDelayMs)))
                            .filter(this::isRetryable)
                            .onRetryExhaustedThrow((spec, signal) ->
                                    new ExternalApiException(
                                            "REGRID parcel service is temporarily unavailable.",
                                            signal.failure())))
                    .block();

            if (body == null || body.isNull()) {
                throw new ExternalApiException(
                        "REGRID returned an empty parcel response.");
            }

            return objectMapper.treeToValue(
                    body, RegridDtos.ParcelLookupResponse.class);

        } catch (ExternalApiException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new ExternalApiException(
                    "Unable to process the REGRID parcel response for "
                            + address + ".", ex);
        }
    }

    private boolean isRetryable(Throwable throwable) {
        String message = throwable.getMessage();
        if (message != null
                && (message.contains("HTTP 400")
                || message.contains("HTTP 401")
                || message.contains("HTTP 403")
                || message.contains("HTTP 404"))) {
            return false;
        }
        return !(throwable instanceof IllegalArgumentException);
    }
}
