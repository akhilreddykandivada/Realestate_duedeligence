package com.realestate.due_diligence_agent.service;

import com.realestate.due_diligence_agent.dto.TimelineEntry;
import com.realestate.due_diligence_agent.entity.OwnershipRecord;
import com.realestate.due_diligence_agent.entity.Permit;
import com.realestate.due_diligence_agent.entity.TaxHistory;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Builds a chronological property timeline from data already gathered by
 * the other modules (ownership, tax history, permits) - no new external
 * calls here, purely a mapping/sorting utility so it's easy to unit test
 * in isolation.
 *
 * Tax history only has a year, not an exact date, so those entries are
 * anchored to January 1st of that year - good enough for chronological
 * ordering relative to other events, not meant to imply an exact date.
 */
@Component
public class PropertyTimelineBuilder {

    public List<TimelineEntry> build(List<OwnershipRecord> ownershipRecords,
                                      List<TaxHistory> taxHistory,
                                      List<Permit> permits) {
        List<TimelineEntry> entries = new ArrayList<>();

        if (ownershipRecords != null) {
            for (OwnershipRecord record : ownershipRecords) {
                if (record.getAcquisitionDate() == null) continue;
                String owner = record.getOwnerName() != null ? record.getOwnerName() : "an unnamed owner";
                String type = record.getOwnershipType() != null ? " (" + record.getOwnershipType() + ")" : "";
                entries.add(TimelineEntry.builder()
                        .date(record.getAcquisitionDate())
                        .label("Ownership change")
                        .description("Acquired by " + owner + type + ".")
                        .build());
            }
        }

        if (taxHistory != null) {
            for (TaxHistory tax : taxHistory) {
                if (tax.getTaxYear() == null) continue;
                entries.add(TimelineEntry.builder()
                        .date(LocalDate.of(tax.getTaxYear(), 1, 1))
                        .label("Tax assessment (" + tax.getTaxYear() + ")")
                        .description(String.format("Assessed value: %s. Tax amount: %s. Payment status: %s.",
                                money(tax.getAssessedValue()), money(tax.getTaxAmount()),
                                tax.getPaymentStatus() != null ? tax.getPaymentStatus() : "unknown"))
                        .build());
            }
        }

        if (permits != null) {
            for (Permit permit : permits) {
                String label = permit.getPermitType() != null ? permit.getPermitType() : "Permit";
                if (permit.getIssueDate() != null) {
                    entries.add(TimelineEntry.builder()
                            .date(permit.getIssueDate())
                            .label("Permit issued: " + label)
                            .description("Status: " + (permit.getStatus() != null ? permit.getStatus() : "unknown")
                                    + (permit.getDescription() != null ? " - " + permit.getDescription() : ""))
                            .build());
                }
                if (permit.getFinalDate() != null) {
                    entries.add(TimelineEntry.builder()
                            .date(permit.getFinalDate())
                            .label("Permit finalized: " + label)
                            .description("Work completed and finalized.")
                            .build());
                }
            }
        }

        entries.sort(Comparator.comparing(TimelineEntry::getDate));
        return entries;
    }

    private String money(Double value) {
        return value != null ? String.format("$%,.2f", value) : "not on record";
    }
}
