package com.realestate.due_diligence_agent.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.realestate.due_diligence_agent.comparable.entity.ComparableListing;
import com.realestate.due_diligence_agent.comparable.repository.ComparableListingRepository;
import com.realestate.due_diligence_agent.comparable.service.ComparableListingService;
import com.realestate.due_diligence_agent.dto.*;
import com.realestate.due_diligence_agent.entity.*;
import com.realestate.due_diligence_agent.integration.ExternalDataNotFoundException;
import com.realestate.due_diligence_agent.report.ExcelReportGenerator;
import com.realestate.due_diligence_agent.report.FileStorageService;
import com.realestate.due_diligence_agent.report.PdfReportGenerator;
import com.realestate.due_diligence_agent.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collections;
import java.util.List;

/**
 * Full report generation flow:
 * REQUESTED -> IN_PROGRESS -> gather due-diligence data -> risk assessment
 * -> comparable listings -> property timeline -> executive summary ->
 * COMPLETED (or FAILED with a reason on error) -> generate PDF/Excel
 * (best-effort - a report is still usable if only file export fails).
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class ReportService {

    private final PropertyRepository propertyRepository;
    private final ReportRepository reportRepository;
    private final RiskAssessmentRepository riskAssessmentRepository;
    private final OwnershipRecordRepository ownershipRecordRepository;
    private final TaxHistoryRepository taxHistoryRepository;
    private final PermitRepository permitRepository;
    private final ComparableListingRepository comparableListingRepository;

    private final DueDiligenceAggregationService aggregationService;
    private final RiskAssessmentService riskAssessmentService;
    private final ComparableListingService comparableListingService;
    private final PropertyTimelineBuilder propertyTimelineBuilder;
    private final ExecutiveSummaryGenerator executiveSummaryGenerator;
    private final PdfReportGenerator pdfReportGenerator;
    private final ExcelReportGenerator excelReportGenerator;
    private final FileStorageService fileStorageService;
    private final ObjectMapper objectMapper;

    @Transactional
    public ReportResponse generateReport(Long propertyId) {
        Property property = getProperty(propertyId);

        Report report = Report.builder()
                .property(property)
                .requestedBy(currentUserLabel())
                .requestedByUser(currentUserOrNull())
                .status(ReportStatus.REQUESTED)
                .build();
        report = reportRepository.save(report);

        try {
            report.setStatus(ReportStatus.IN_PROGRESS);
            reportRepository.save(report);

            DueDiligenceAggregateResponse data = aggregationService.aggregate(propertyId);

            RiskAssessmentService.RiskOutcome riskOutcome = riskAssessmentService.runStrategies(report, data);

            List<ComparableListing> comparables;
            try {
                comparables = comparableListingService.getComparables(propertyId);
            } catch (Exception e) {
                log.warn("Comparable listings unavailable for property {}: {}", propertyId, e.getMessage());
                comparables = Collections.emptyList();
            }

            List<TimelineEntry> timeline = propertyTimelineBuilder.build(
                    ownershipRecordRepository.findByPropertyId(propertyId),
                    taxHistoryRepository.findByPropertyIdOrderByTaxYearDesc(propertyId),
                    permitRepository.findByPropertyId(propertyId));

            String summary = executiveSummaryGenerator.generate(
                    property, riskOutcome.overallScore(), riskOutcome.results(), comparables);

            report.setRiskScore(riskOutcome.overallScore());
            report.setExecutiveSummary(summary);
            report.setPropertyTimeline(serializeTimeline(timeline));
            report.setStatus(ReportStatus.COMPLETED);
            reportRepository.save(report);

            generateFilesBestEffort(property, report, timeline, comparables);

            return toResponse(report, riskOutcome.results(), timeline, comparables);

        } catch (Exception e) {
            log.error("Report generation failed for property {}: {}", propertyId, e.getMessage());
            report.setStatus(ReportStatus.FAILED);
            report.setFailureReason(e.getMessage() != null ? e.getMessage() : e.getClass().getSimpleName());
            reportRepository.save(report);
            return toResponse(report, Collections.emptyList(), Collections.emptyList(), Collections.emptyList());
        }
    }

    /** PDF/Excel generation is best-effort - a report with COMPLETED data is still useful without the files. */
    private void generateFilesBestEffort(Property property, Report report,
                                          List<TimelineEntry> timeline, List<ComparableListing> comparables) {
        try {
            List<RiskAssessment> savedAssessments = riskAssessmentRepository.findByReportId(report.getId());

            byte[] pdf = pdfReportGenerator.generate(property, report, savedAssessments, timeline, comparables);
            report.setPdfUrl(fileStorageService.save(pdf, "report-" + report.getId() + ".pdf"));

            byte[] excel = excelReportGenerator.generate(property, report, savedAssessments, timeline, comparables);
            report.setExcelUrl(fileStorageService.save(excel, "report-" + report.getId() + ".xlsx"));

            reportRepository.save(report);
        } catch (Exception e) {
            log.warn("PDF/Excel generation failed for report {}: {}", report.getId(), e.getMessage());
        }
    }

    @Transactional(readOnly = true)
    public ReportResponse getReport(Long reportId) {
        Report report = getReportOrThrow(reportId);

        List<RiskAssessment> assessments = riskAssessmentRepository.findByReportId(reportId);
        List<RiskCategoryResult> categories = assessments.stream()
                .map(a -> RiskCategoryResult.builder()
                        .category(a.getCategory()).indicator(a.getIndicator())
                        .score(a.getScore()).notes(a.getNotes()).build())
                .toList();

        List<TimelineEntry> timeline = deserializeTimeline(report.getPropertyTimeline());
        List<ComparableListing> comparables = comparableListingRepository.findByPropertyId(report.getProperty().getId());

        return toResponse(report, categories, timeline, comparables);
    }

    /**
     * GET /api/reports?user={userId} - access control: only the user
     * themselves, or an ADMINISTRATOR, may view another user's report list.
     * Lightweight list view - no nested timeline/comparables detail per
     * entry, call GET /api/reports/{id} for that.
     */
    @Transactional(readOnly = true)
    public List<ReportResponse> getReportsForUser(Long userId) {
        User current = currentUserOrNull();
        if (current == null) {
            throw new AccessDeniedException("Authentication required.");
        }
        boolean isSelf = current.getId() != null && current.getId().equals(userId);
        boolean isAdmin = current.getRole() == Role.ADMINISTRATOR;
        if (!isSelf && !isAdmin) {
            throw new AccessDeniedException("You do not have permission to view another user's reports.");
        }

        return reportRepository.findByRequestedByUserIdOrderByCreatedAtDesc(userId).stream()
                .map(r -> toResponse(r, Collections.emptyList(), Collections.emptyList(), Collections.emptyList()))
                .toList();
    }

    @Transactional(readOnly = true)
    public byte[] getPdfBytes(Long reportId) {
        Report report = getReportOrThrow(reportId);
        if (report.getPdfUrl() == null) {
            throw new ExternalDataNotFoundException("No PDF has been generated yet for report " + reportId + ".");
        }
        return fileStorageService.read(report.getPdfUrl());
    }

    @Transactional(readOnly = true)
    public byte[] getExcelBytes(Long reportId) {
        Report report = getReportOrThrow(reportId);
        if (report.getExcelUrl() == null) {
            throw new ExternalDataNotFoundException("No Excel file has been generated yet for report " + reportId + ".");
        }
        return fileStorageService.read(report.getExcelUrl());
    }

    private Report getReportOrThrow(Long reportId) {
        return reportRepository.findById(reportId)
                .orElseThrow(() -> new ExternalDataNotFoundException("Report not found with id: " + reportId));
    }

    private Property getProperty(Long id) {
        return propertyRepository.findById(id)
                .orElseThrow(() -> new ExternalDataNotFoundException("Property not found with id: " + id));
    }

    private String serializeTimeline(List<TimelineEntry> timeline) {
        try {
            return objectMapper.writeValueAsString(timeline);
        } catch (Exception e) {
            log.warn("Unable to serialize timeline: {}", e.getMessage());
            return "[]";
        }
    }

    private List<TimelineEntry> deserializeTimeline(String json) {
        if (json == null || json.isBlank()) return Collections.emptyList();
        try {
            return objectMapper.readValue(json, new TypeReference<List<TimelineEntry>>() {});
        } catch (Exception e) {
            log.warn("Unable to deserialize timeline: {}", e.getMessage());
            return Collections.emptyList();
        }
    }

    private String currentUserLabel() {
        User user = currentUserOrNull();
        return user != null ? user.getFullName() + " (" + user.getEmail() + ")" : "Unknown";
    }

    private User currentUserOrNull() {
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return principal instanceof User user ? user : null;
    }

    private ReportResponse toResponse(Report report, List<RiskCategoryResult> categories,
                                       List<TimelineEntry> timeline, List<ComparableListing> comparables) {
        return ReportResponse.builder()
                .id(report.getId())
                .propertyId(report.getProperty().getId())
                .requestedBy(report.getRequestedBy())
                .status(report.getStatus() != null ? report.getStatus().name() : null)
                .createdAt(report.getCreatedAt())
                .riskScore(report.getRiskScore())
                .executiveSummary(report.getExecutiveSummary())
                .failureReason(report.getFailureReason())
                .pdfUrl(report.getPdfUrl())
                .excelUrl(report.getExcelUrl())
                .riskCategories(categories)
                .timeline(timeline)
                .comparables(comparables)
                .build();
    }
}
