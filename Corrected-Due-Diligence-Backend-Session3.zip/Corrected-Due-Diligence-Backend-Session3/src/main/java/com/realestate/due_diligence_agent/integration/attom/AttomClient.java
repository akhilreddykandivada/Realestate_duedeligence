package com.realestate.due_diligence_agent.integration.attom;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.realestate.due_diligence_agent.integration.ExternalApiException;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatusCode;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.util.retry.Retry;

import java.time.Duration;

@Component
@RequiredArgsConstructor
public class AttomClient {
    private final WebClient.Builder webClientBuilder;
    private final ObjectMapper objectMapper;

    private WebClient webClient;

    @Value("${attom.base-url:https://api.gateway.attomdata.com/propertyapi/v1.0.0}")
    private String baseUrl;
    @Value("${attom.api-key:}")
    private String apiKey;
    @Value("${attom.retry.max-attempts:3}")
    private long maxAttempts;
    @Value("${attom.retry.delay-ms:600}")
    private long retryDelayMs;
    @Value("${attom.basic-profile-path:/property/basicprofile}")
    private String basicProfilePath;
    @Value("${attom.detail-owner-path:/property/detailowner}")
    private String detailOwnerPath;
    @Value("${attom.assessment-path:/assessment}")
    private String assessmentPath;

    @PostConstruct
    private void init() {
        this.webClient = webClientBuilder.baseUrl(baseUrl).build();
    }

    public AttomDtos.Response<AttomDtos.Property> basicProfile(String address) {
        return get(basicProfilePath, address, null, "ATTOM basic profile");
    }

    public AttomDtos.Response<AttomDtos.Property> basicProfile(String address, String location) {
        return get(basicProfilePath, address, location, "ATTOM basic profile");
    }

    public AttomDtos.Response<AttomDtos.Property> detailOwner(String address) {
        return get(detailOwnerPath, address, null, "ATTOM owner details");
    }

    public AttomDtos.Response<AttomDtos.Property> detailOwner(String address, String location) {
        return get(detailOwnerPath, address, location, "ATTOM owner details");
    }

    public AttomDtos.Response<AttomDtos.Property> assessment(String address) {
        return get(assessmentPath, address, null, "ATTOM assessment");
    }

    public AttomDtos.Response<AttomDtos.Property> assessment(String address, String location) {
        return get(assessmentPath, address, location, "ATTOM assessment");
    }

    /**
     * Raw ATTOM response used by the service for provider fields that vary
     * between ATTOM products. Typed DTO methods remain available to existing code.
     */
    public JsonNode raw(String path, String address, String location, String operation) {
        if (!StringUtils.hasText(apiKey)) {
            throw new ExternalApiException(
                    "ATTOM API key is not configured. Set ATTOM_API_KEY before using " + operation + ".");
        }
        if (!StringUtils.hasText(address)) {
            throw new ExternalApiException("Property address is missing for " + operation + ".");
        }

        try {
            JsonNode body = webClient.get()
                    .uri(uriBuilder -> {
                        var builder = uriBuilder.path(path)
                                .queryParam("address1", address.trim());
                        if (StringUtils.hasText(location)) {
                            builder.queryParam("address2", location.trim());
                        }
                        return builder.build();
                    })
                    .header("apikey", apiKey.trim())
                    .header("Accept", "application/json")
                    .retrieve()
                    .onStatus(HttpStatusCode::isError, response ->
                            response.bodyToMono(String.class)
                                    .defaultIfEmpty("")
                                    .map(errorBody -> new ExternalApiException(
                                            (response.statusCode().value() == 429 || response.statusCode().is5xxServerError()
                                                    ? "RETRYABLE_ATTOM_HTTP " : "ATTOM_HTTP ")
                                                    + operation + " failed with HTTP "
                                                    + response.statusCode().value()
                                                    + (StringUtils.hasText(errorBody) ? ": " + errorBody : "."))))
                    .bodyToMono(JsonNode.class)
                    .retryWhen(Retry.backoff(
                                    Math.max(1, maxAttempts - 1),
                                    Duration.ofMillis(Math.max(100, retryDelayMs)))
                            .filter(this::isRetryable)
                            .onRetryExhaustedThrow((spec, signal) ->
                                    signal.failure() instanceof ExternalApiException
                                            ? signal.failure()
                                            : new ExternalApiException(
                                                    operation + " failed after " + maxAttempts + " attempts.",
                                                    signal.failure())))
                    .block();

            if (body == null || body.isNull()) {
                throw new ExternalApiException(operation + " returned an empty response.");
            }

            int providerCode = body.path("status").path("code").asInt(0);
            if (providerCode >= 400) {
                throw new ExternalApiException(
                        operation + " was rejected by ATTOM (code " + providerCode + "): "
                                + body.path("status").path("msg").asText("unknown error"));
            }
            return body;
        } catch (ExternalApiException ex) {
            throw new ExternalApiException(cleanDiagnosticMessage(ex.getMessage()), ex);
        } catch (Exception ex) {
            throw new ExternalApiException(
                    "Unable to process the " + operation + " response from ATTOM: "
                            + (ex.getMessage() == null ? ex.getClass().getSimpleName() : ex.getMessage()), ex);
        }
    }

    private AttomDtos.Response<AttomDtos.Property> get(
            String path, String address, String location, String operation) {

        if (!StringUtils.hasText(apiKey)) {
            throw new ExternalApiException(
                    "ATTOM API key is not configured. Set ATTOM_API_KEY before using " + operation + ".");
        }
        if (!StringUtils.hasText(address)) {
            throw new ExternalApiException("Property address is missing for " + operation + ".");
        }

        try {
            JsonNode body = webClient.get()
                    .uri(uriBuilder -> {
                        var builder = uriBuilder.path(path)
                                .queryParam("address1", address.trim());
                        if (StringUtils.hasText(location)) {
                            builder.queryParam("address2", location.trim());
                        }
                        return builder.build();
                    })
                    .header("apikey", apiKey.trim())
                    .header("Accept", "application/json")
                    .retrieve()
                    .onStatus(HttpStatusCode::isError, response ->
                            response.bodyToMono(String.class)
                                    .defaultIfEmpty("")
                                    .map(errorBody -> {
                                        String detail = StringUtils.hasText(errorBody)
                                                ? ": " + errorBody
                                                : ".";
                                        boolean retryable = response.statusCode().value() == 429
                                                || response.statusCode().is5xxServerError();
                                        String prefix = retryable ? "RETRYABLE_ATTOM_HTTP " : "ATTOM_HTTP ";
                                        return new ExternalApiException(
                                                prefix + operation + " failed with HTTP "
                                                        + response.statusCode().value() + detail);
                                    }))
                    .bodyToMono(JsonNode.class)
                    .retryWhen(Retry.backoff(
                                    Math.max(1, maxAttempts - 1),
                                    Duration.ofMillis(Math.max(100, retryDelayMs)))
                            .filter(this::isRetryable)
                            .onRetryExhaustedThrow((spec, signal) ->
                                    signal.failure() instanceof ExternalApiException
                                            ? signal.failure()
                                            : new ExternalApiException(
                                                    operation + " failed after " + maxAttempts + " attempts.",
                                                    signal.failure())))
                    .block();

            if (body == null || body.isNull()) {
                throw new ExternalApiException(operation + " returned an empty response.");
            }

            int providerCode = body.path("status").path("code").asInt(0);
            if (providerCode >= 400) {
                throw new ExternalApiException(
                        operation + " was rejected by ATTOM (code " + providerCode + "): "
                                + body.path("status").path("msg").asText("unknown error"));
            }

            return objectMapper.treeToValue(
                    body,
                    objectMapper.getTypeFactory().constructParametricType(
                            AttomDtos.Response.class, AttomDtos.Property.class));

        } catch (ExternalApiException ex) {
            // Never hide the real provider/configuration error behind a generic
            // "temporarily unavailable" message. This is especially important
            // while diagnosing ATTOM credentials, quotas and endpoint paths.
            throw new ExternalApiException(cleanDiagnosticMessage(ex.getMessage()), ex);
        } catch (Exception ex) {
            throw new ExternalApiException(
                    "Unable to process the " + operation + " response from ATTOM: "
                            + (ex.getMessage() == null ? ex.getClass().getSimpleName() : ex.getMessage()), ex);
        }
    }

    private boolean isRetryable(Throwable throwable) {
        return throwable instanceof ExternalApiException
                && throwable.getMessage() != null
                && throwable.getMessage().startsWith("RETRYABLE_ATTOM_HTTP ");
    }

    private String cleanDiagnosticMessage(String message) {
        if (message == null) return "ATTOM request failed.";
        return message.replaceFirst("^RETRYABLE_ATTOM_HTTP ", "")
                .replaceFirst("^ATTOM_HTTP ", "");
    }
}
