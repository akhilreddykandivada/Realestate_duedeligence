package com.realestate.due_diligence_agent.comparable.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.realestate.due_diligence_agent.comparable.client.RapidApiListingClient;
import com.realestate.due_diligence_agent.comparable.dto.RapidApiListingResponse;
import com.realestate.due_diligence_agent.comparable.entity.ComparableListing;
import com.realestate.due_diligence_agent.comparable.repository.ComparableListingRepository;
import com.realestate.due_diligence_agent.comparable.util.DistanceCalculator;
import com.realestate.due_diligence_agent.entity.Property;
import com.realestate.due_diligence_agent.integration.ExternalDataNotFoundException;
import com.realestate.due_diligence_agent.repository.PropertyRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Database-first, same pattern as the rest of the project. Listings older
 * than MAX_AGE_DAYS are considered stale and trigger a fresh RapidAPI
 * call rather than serving indefinitely-old market data.
 */
@Service
@RequiredArgsConstructor
public class ComparableListingService {

    private static final int MAX_AGE_DAYS = 30;

    private final PropertyRepository propertyRepository;
    private final ComparableListingRepository comparableListingRepository;
    private final RapidApiListingClient rapidApiListingClient;

    @Transactional
    public List<ComparableListing> getComparables(Long propertyId) {
        Property property = getProperty(propertyId);

        List<ComparableListing> existing = comparableListingRepository.findByPropertyId(propertyId);
        if (!existing.isEmpty() && !isOutdated(existing)) {
            return existing;
        }

        String locationQuery = buildLocationQuery(property);
        RapidApiListingResponse response = rapidApiListingClient.searchListings(locationQuery);

        if (response.getListings().isEmpty()) {
            if (!existing.isEmpty()) return existing; // fall back to stale data rather than nothing
            throw new ExternalDataNotFoundException("No comparable listings found near property " + propertyId + ".");
        }

        List<ComparableListing> mapped = new ArrayList<>();
        for (JsonNode listing : response.getListings()) {
            mapped.add(mapListing(property, listing));
        }
        return comparableListingRepository.saveAll(mapped);
    }

    private boolean isOutdated(List<ComparableListing> listings) {
        LocalDateTime cutoff = LocalDateTime.now().minusDays(MAX_AGE_DAYS);
        return listings.stream().allMatch(l -> l.getFetchedAt() != null && l.getFetchedAt().isBefore(cutoff));
    }

    private String buildLocationQuery(Property property) {
        return StringUtils.hasText(property.getLocation()) ? property.getLocation() : property.getAddress();
    }

    /**
     * Field names here are best-effort guesses at common RapidAPI
     * real-estate schema conventions - VERIFY against your actual
     * subscribed API's real response and adjust the candidate keys below
     * if any field comes back null that shouldn't.
     */
    private ComparableListing mapListing(Property property, JsonNode listing) {
        String address = find(listing, "address", "full_address", "formatted_address", "street_address");
        Double price = findDouble(listing, "list_price", "price", "listPrice");
        LocalDate listedDate = findDate(listing, "list_date", "listed_date", "listing_date");
        Double sqft = findDouble(listing, "sqft", "square_feet", "building_size", "living_area");
        Double lat = findDouble(listing, "latitude", "lat");
        Double lon = findDouble(listing, "longitude", "lon", "lng");

        Double distance = null;
        if (property.getLatitude() != null && property.getLongitude() != null && lat != null && lon != null) {
            distance = DistanceCalculator.calculateMiles(property.getLatitude(), property.getLongitude(), lat, lon);
        }

        return ComparableListing.builder()
                .property(property)
                .comparableAddress(address)
                .price(price)
                .distanceMiles(distance)
                .listedDate(listedDate)
                .squareFeet(sqft)
                .latitude(lat)
                .longitude(lon)
                .source("RAPIDAPI")
                .build();
    }

    private Property getProperty(Long id) {
        return propertyRepository.findById(id)
                .orElseThrow(() -> new ExternalDataNotFoundException("Property not found with id: " + id));
    }

    private String find(JsonNode node, String... keys) {
        for (String key : keys) {
            JsonNode value = node.get(key);
            if (value != null && !value.isNull() && StringUtils.hasText(value.asText())) return value.asText();
        }
        return null;
    }

    private Double findDouble(JsonNode node, String... keys) {
        String text = find(node, keys);
        if (text == null) return null;
        try { return Double.parseDouble(text); } catch (NumberFormatException e) { return null; }
    }

    private LocalDate findDate(JsonNode node, String... keys) {
        String text = find(node, keys);
        if (text == null) return null;
        try { return LocalDate.parse(text.length() > 10 ? text.substring(0, 10) : text); }
        catch (Exception e) { return null; }
    }
}
