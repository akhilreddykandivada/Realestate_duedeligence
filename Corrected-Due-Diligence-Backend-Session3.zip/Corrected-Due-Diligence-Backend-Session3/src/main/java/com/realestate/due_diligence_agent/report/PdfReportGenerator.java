package com.realestate.due_diligence_agent.report;

import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Cell;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.element.Text;
import com.itextpdf.layout.properties.UnitValue;
import com.realestate.due_diligence_agent.comparable.entity.ComparableListing;
import com.realestate.due_diligence_agent.dto.TimelineEntry;
import com.realestate.due_diligence_agent.entity.Property;
import com.realestate.due_diligence_agent.entity.Report;
import com.realestate.due_diligence_agent.entity.RiskAssessment;
import org.springframework.stereotype.Component;

import java.io.ByteArrayOutputStream;
import java.util.List;

@Component
public class PdfReportGenerator {

    public byte[] generate(Property property, Report report, List<RiskAssessment> riskAssessments,
                            List<TimelineEntry> timeline, List<ComparableListing> comparables) {
        ByteArrayOutputStream out = new ByteArrayOutputStream();

        try (PdfWriter writer = new PdfWriter(out);
             PdfDocument pdfDoc = new PdfDocument(writer);
             Document document = new Document(pdfDoc)) {

            document.add(boldParagraph("Property Due Diligence Report", 20));
            document.add(new Paragraph(safe(property.getAddress())).setFontSize(14));
            if (property.getLocation() != null) {
                document.add(new Paragraph(property.getLocation()).setFontSize(11));
            }

            document.add(boldParagraph("\nExecutive Summary", 16));
            document.add(new Paragraph(safe(report.getExecutiveSummary())));

            document.add(boldParagraph("\nRisk Assessment", 16));
            document.add(new Paragraph(String.format("Overall risk score: %.1f / 100",
                    report.getRiskScore() != null ? report.getRiskScore() : 0.0)));

            Table riskTable = new Table(UnitValue.createPercentArray(new float[]{2, 1, 4}));
            riskTable.setWidth(UnitValue.createPercentValue(100));
            riskTable.addHeaderCell(new Cell().add(new Paragraph(new Text("Category"))));
            riskTable.addHeaderCell(new Cell().add(new Paragraph(new Text("Score"))));
            riskTable.addHeaderCell(new Cell().add(new Paragraph(new Text("Indicator"))));
            if (riskAssessments != null) {
                for (RiskAssessment ra : riskAssessments) {
                    riskTable.addCell(new Cell().add(new Paragraph(safe(ra.getCategory()))));
                    riskTable.addCell(new Cell().add(new Paragraph(ra.getScore() != null ? String.format("%.0f", ra.getScore()) : "-")));
                    riskTable.addCell(new Cell().add(new Paragraph(safe(ra.getIndicator()))));
                }
            }
            document.add(riskTable);

            document.add(boldParagraph("\nProperty Timeline", 16));
            if (timeline == null || timeline.isEmpty()) {
                document.add(new Paragraph("No timeline events on record."));
            } else {
                for (TimelineEntry entry : timeline) {
                    document.add(new Paragraph(String.format("%s - %s: %s",
                            entry.getDate(), entry.getLabel(), entry.getDescription())).setFontSize(10));
                }
            }

            document.add(boldParagraph("\nComparable Listings", 16));
            if (comparables == null || comparables.isEmpty()) {
                document.add(new Paragraph("No comparable listings on record."));
            } else {
                Table compTable = new Table(UnitValue.createPercentArray(new float[]{3, 2, 1}));
                compTable.setWidth(UnitValue.createPercentValue(100));
                compTable.addHeaderCell(new Cell().add(new Paragraph(new Text("Address"))));
                compTable.addHeaderCell(new Cell().add(new Paragraph(new Text("Price"))));
                compTable.addHeaderCell(new Cell().add(new Paragraph(new Text("Distance (mi)"))));
                for (ComparableListing comp : comparables) {
                    compTable.addCell(new Cell().add(new Paragraph(safe(comp.getComparableAddress()))));
                    compTable.addCell(new Cell().add(new Paragraph(
                            comp.getPrice() != null ? String.format("$%,.0f", comp.getPrice()) : "-")));
                    compTable.addCell(new Cell().add(new Paragraph(
                            comp.getDistanceMiles() != null ? String.format("%.1f", comp.getDistanceMiles()) : "-")));
                }
                document.add(compTable);
            }
        } catch (Exception e) {
            throw new ReportGenerationException("Unable to generate PDF report", e);
        }
        return out.toByteArray();
    }

    private Paragraph boldParagraph(String value, float fontSize) {
        return new Paragraph(new Text(value)).setFontSize(fontSize);
    }

    private String safe(String value) {
        return value != null ? value : "Not available";
    }
}
