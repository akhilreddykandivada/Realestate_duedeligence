package com.realestate.due_diligence_agent.report;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * Local filesystem storage for generated report files. Files are served
 * back out through the authenticated GET /api/reports/{id}/pdf and
 * /excel controller endpoints (not a public static file path), since
 * due-diligence report content is sensitive - "excel_url"/"pdf_url" on
 * Report just store the filename, not a directly-browsable URL.
 */
@Service
public class FileStorageService {

    @Value("${report.storage.directory:./generated-reports}")
    private String storageDirectory;

    public String save(byte[] content, String filename) {
        try {
            Path dir = Paths.get(storageDirectory);
            Files.createDirectories(dir);
            Path filePath = dir.resolve(filename);
            Files.write(filePath, content);
            return filename;
        } catch (IOException e) {
            throw new ReportGenerationException("Unable to save report file: " + filename, e);
        }
    }

    public byte[] read(String filename) {
        try {
            Path filePath = Paths.get(storageDirectory).resolve(filename);
            if (!Files.exists(filePath)) {
                throw new ReportGenerationException("Report file not found: " + filename, null);
            }
            return Files.readAllBytes(filePath);
        } catch (IOException e) {
            throw new ReportGenerationException("Unable to read report file: " + filename, e);
        }
    }
}
