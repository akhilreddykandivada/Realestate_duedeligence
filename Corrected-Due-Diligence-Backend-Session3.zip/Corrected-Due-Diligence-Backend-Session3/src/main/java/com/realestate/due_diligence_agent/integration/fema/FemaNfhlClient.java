package com.realestate.due_diligence_agent.integration.fema;

import com.fasterxml.jackson.databind.JsonNode;
import com.realestate.due_diligence_agent.integration.ExternalApiException;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatusCode;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.util.retry.Retry;

import java.time.Duration;

/**
 * Client for FEMA's National Flood Hazard Layer (NFHL), an ArcGIS REST
 * service queried by point (the property's lat/lng from Address
 * Validation). No API key required.
 *
 * IMPORTANT: I don't have access to the exact FEMA_NFHL_BASE_URL / layer
 * IDs your mentor shared by email - FEMA_NFHL_BASE_URL below defaults to
 * FEMA's public NFHL MapServer root, and the two layer IDs default to the
 * commonly-documented "Flood Hazard Zones" (28) and "FIRM Panels" (3)
 * layers on that service. Verify both against the docs you were given and
 * override via FEMA_FLOOD_ZONE_LAYER / FEMA_FIRM_PANEL_LAYER if different -
 * no code change needed, they're both externalized.
 */
@Component
@RequiredArgsConstructor
public class FemaNfhlClient {

    private final WebClient.Builder webClientBuilder;
    // Built once after @Value injection - see AttomClient for why this
    // matters: mutating a shared WebClient.Builder per-request is a data
    // race once calls run in parallel, which the aggregation endpoint does.
    private WebClient webClient;

    @Value("${fema.nfhl.base-url:https://hazards.fema.gov/gis/nfhl/rest/services/public/NFHL/MapServer}")
    private String baseUrl;
    @Value("${fema.nfhl.flood-zone-layer:28}")
    private String floodZoneLayer;
    @Value("${fema.nfhl.firm-panel-layer:3}")
    private String firmPanelLayer;
    @Value("${fema.nfhl.retry.max-attempts:3}")
    private long maxAttempts;
    @Value("${fema.nfhl.retry.delay-ms:600}")
    private long retryDelayMs;

    @PostConstruct
    private void init() {
        this.webClient = webClientBuilder.baseUrl(baseUrl).build();
    }

    public FemaDtos.QueryResult queryFloodHazardZone(double latitude, double longitude) {
        return query(floodZoneLayer, latitude, longitude, "FEMA flood hazard zone lookup");
    }

    public FemaDtos.QueryResult queryFirmPanel(double latitude, double longitude) {
        return query(firmPanelLayer, latitude, longitude, "FEMA FIRM panel lookup");
    }

    private FemaDtos.QueryResult query(String layer, double latitude, double longitude, String operation) {
        try {
            JsonNode body = webClient
                    .get()
                    .uri(uriBuilder -> uriBuilder.path("/" + layer + "/query")
                            .queryParam("geometry", longitude + "," + latitude)
                            .queryParam("geometryType", "esriGeometryPoint")
                            .queryParam("inSR", "4326")
                            .queryParam("spatialRel", "esriSpatialRelIntersects")
                            .queryParam("outFields", "*")
                            .queryParam("f", "json")
                            .build())
                    .retrieve()
                    .onStatus(HttpStatusCode::isError, status -> status.createException())
                    .bodyToMono(JsonNode.class)
                    .retryWhen(Retry.backoff(Math.max(1, maxAttempts - 1), Duration.ofMillis(Math.max(100, retryDelayMs)))
                            .filter(t -> !(t instanceof IllegalArgumentException))
                            .onRetryExhaustedThrow((spec, signal) -> new ExternalApiException(
                                    operation + " is temporarily unavailable.", signal.failure())))
                    .block();

            if (body != null && body.has("error")) {
                throw new ExternalApiException(operation + " was rejected by FEMA: "
                        + body.path("error").path("message").asText("unknown error"));
            }
            return FemaDtos.QueryResult.from(body);
        } catch (ExternalApiException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new ExternalApiException("Unable to process the " + operation + " response from FEMA.", ex);
        }
    }
}
