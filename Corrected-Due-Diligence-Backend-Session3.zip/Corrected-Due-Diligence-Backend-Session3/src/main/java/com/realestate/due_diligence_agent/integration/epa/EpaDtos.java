package com.realestate.due_diligence_agent.integration.epa;

import com.fasterxml.jackson.databind.JsonNode;
import lombok.Getter;

import java.util.ArrayList;
import java.util.List;

/**
 * EPA Envirofacts' "efservice" REST API returns a plain JSON array of row
 * objects (not an envelope like FEMA/Shovels), one object per matching
 * facility record.
 */
public class EpaDtos {

    @Getter
    public static class FacilityPage {
        private final List<JsonNode> rows = new ArrayList<>();

        public static FacilityPage from(JsonNode body) {
            FacilityPage page = new FacilityPage();
            if (body != null && body.isArray()) {
                body.forEach(page.rows::add);
            }
            return page;
        }

        public boolean isEmpty() { return rows.isEmpty(); }
    }
}
