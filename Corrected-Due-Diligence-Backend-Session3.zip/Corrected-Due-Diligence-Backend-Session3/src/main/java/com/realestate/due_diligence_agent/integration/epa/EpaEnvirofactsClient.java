package com.realestate.due_diligence_agent.integration.epa;

import com.fasterxml.jackson.databind.JsonNode;
import com.realestate.due_diligence_agent.integration.ExternalApiException;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatusCode;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.util.retry.Retry;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

/**
 * EPA Envirofacts "efservice" tabular REST API - no key/account required.
 * URL shape: {base}/{table}/{column}/{operator}/{value}/{page-slice}/JSON
 *
 * Queries the FRS (Facility Registry Service) program-facility table by
 * ZIP code by default, since ZIP is the most reliable of the fields the
 * mentor spec lists (address/zip/facility name) to match exactly against
 * EPA's own postal-code column. Pagination is handled via Envirofacts'
 * "/ROWS/{start}:{end}/" row-slice segment, fetched in pages until a page
 * comes back short of the page size (i.e. the last page).
 *
 * I don't have the exact EPA_ENVIROFACTS_BASE_URL / table name from the
 * docs shared by email - defaults below target the public FRS table;
 * verify and override via application.properties / env vars if different.
 */
@Component
@RequiredArgsConstructor
public class EpaEnvirofactsClient {

    private final WebClient.Builder webClientBuilder;
    private WebClient webClient;

    @Value("${epa.envirofacts.base-url:https://data.epa.gov/efservice}")
    private String baseUrl;
    @Value("${epa.envirofacts.table:FRS_PROGRAM_FACILITY}")
    private String table;
    @Value("${epa.envirofacts.zip-column:POSTAL_CODE}")
    private String zipColumn;
    @Value("${epa.envirofacts.page-size:100}")
    private int pageSize;
    @Value("${epa.envirofacts.max-pages:5}")
    private int maxPages;

    @PostConstruct
    private void init() {
        this.webClient = webClientBuilder.baseUrl(baseUrl).build();
    }

    /** Fetches every facility record matching the given ZIP, across as many pages as needed. */
    public List<JsonNode> findByZipCode(String zipCode) {
        List<JsonNode> all = new ArrayList<>();
        for (int page = 0; page < maxPages; page++) {
            int start = page * pageSize;
            int end = start + pageSize - 1;
            EpaDtos.FacilityPage result = fetchPage(zipCode, start, end);
            all.addAll(result.getRows());
            if (result.getRows().size() < pageSize) break; // last page
        }
        return all;
    }

    private EpaDtos.FacilityPage fetchPage(String zipCode, int start, int end) {
        try {
            String path = String.format("/%s/%s/EQUALS/%s/ROWS/%d:%d/JSON",
                    table, zipColumn, zipCode, start, end);

            JsonNode body = webClient
                    .get()
                    .uri(path)
                    .retrieve()
                    .onStatus(HttpStatusCode::isError, status -> status.createException())
                    .bodyToMono(JsonNode.class)
                    .retryWhen(Retry.backoff(2, Duration.ofMillis(600))
                            .filter(t -> !(t instanceof IllegalArgumentException))
                            .onRetryExhaustedThrow((spec, signal) -> new ExternalApiException(
                                    "EPA Envirofacts is temporarily unavailable.", signal.failure())))
                    .block();

            return EpaDtos.FacilityPage.from(body);
        } catch (ExternalApiException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new ExternalApiException("Unable to process the EPA Envirofacts response.", ex);
        }
    }
}
