package com.realestate.due_diligence_agent.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "tax_history")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class TaxHistory {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "property_id", nullable = false)
    private Property property;

    @Column(name = "tax_year")
    private Integer taxYear;

    @Column(name = "assessed_value")
    private Double assessedValue;

    @Column(name = "tax_amount")
    private Double taxAmount;

    @Column(name = "payment_status")
    private String paymentStatus;
}
