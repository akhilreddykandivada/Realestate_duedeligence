package com.realestate.due_diligence_agent.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "risk_assessments")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class RiskAssessment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "report_id", nullable = false)
    private Report report;

    /** TAX_DUE, FLOOD_RISK, ZONING_COMPLIANCE, PERMIT_COMPLIANCE, OWNERSHIP, LEGAL */
    @Column(nullable = false)
    private String category;

    @Column(columnDefinition = "TEXT")
    private String indicator;

    /** 0-100, higher = riskier. */
    @Column(nullable = false)
    private Double score;

    @Column(columnDefinition = "TEXT")
    private String notes;
}
