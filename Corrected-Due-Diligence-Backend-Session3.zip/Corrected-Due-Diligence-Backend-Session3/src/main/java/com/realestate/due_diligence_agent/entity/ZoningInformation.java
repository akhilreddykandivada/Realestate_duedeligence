package com.realestate.due_diligence_agent.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "zoning_information")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class ZoningInformation {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @JsonIgnore
    @OneToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "property_id", nullable = false, unique = true)
    private Property property;

    @Column(name = "zoning_classification")
    private String zoningClassification;

    @Column(name = "land_use")
    private String landUse;

    @Column(name = "setback_requirements")
    private String setbackRequirements;

    @Column(name = "zoning_compliance")
    private String zoningCompliance;
}
