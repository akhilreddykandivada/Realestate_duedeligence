package com.realestate.due_diligence_agent.risk;

import com.realestate.due_diligence_agent.dto.DueDiligenceAggregateResponse;
import com.realestate.due_diligence_agent.dto.RiskCategoryResult;
import org.springframework.stereotype.Component;

/**
 * Placeholder strategy - there is no legal-documents data source
 * integrated yet, so this always returns a neutral/low-risk score with an
 * indicator that clearly says this category is not fully assessed, rather
 * than pretending to have evaluated something it can't see.
 */
@Component
public class LegalRiskStrategy implements RiskCategoryStrategy {

    @Override
    public String getCategory() { return "LEGAL_RISK"; }

    @Override
    public double getWeight() { return 0.10; }

    @Override
    public RiskCategoryResult evaluate(DueDiligenceAggregateResponse data) {
        return RiskCategoryResult.builder()
                .category(getCategory())
                .score(20.0)
                .indicator("Legal document data is currently unavailable")
                .notes("No legal-documents data source is integrated yet (liens, judgments, pending litigation, etc.) - "
                        + "this category is NOT fully assessed. The neutral/low score reflects the absence of a known "
                        + "issue, not a confirmed clean legal record. Do not rely on this score alone for legal risk.")
                .build();
    }
}
