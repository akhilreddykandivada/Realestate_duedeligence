package com.realestate.due_diligence_agent.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.realestate.due_diligence_agent.entity.EnvironmentalRecord;
import com.realestate.due_diligence_agent.entity.Property;
import com.realestate.due_diligence_agent.integration.ExternalDataNotFoundException;
import com.realestate.due_diligence_agent.integration.epa.EpaEnvirofactsClient;
import com.realestate.due_diligence_agent.repository.EnvironmentalRecordRepository;
import com.realestate.due_diligence_agent.repository.PropertyRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Database-first, same pattern as the other new modules. EPA Envirofacts
 * has no key/rate limit concerns, but this still avoids re-querying on
 * every request once a property's records are cached.
 */
@Service
@RequiredArgsConstructor
public class EnvironmentalRecordService {

    private static final Pattern ZIP_PATTERN = Pattern.compile("\\b(\\d{5})(?:-\\d{4})?\\b");

    private final PropertyRepository propertyRepository;
    private final EnvironmentalRecordRepository environmentalRecordRepository;
    private final EpaEnvirofactsClient epaEnvirofactsClient;

    @Transactional
    public List<EnvironmentalRecord> getEnvironmentalRecords(Long propertyId) {
        Property property = getProperty(propertyId);

        List<EnvironmentalRecord> existing = environmentalRecordRepository.findByPropertyId(propertyId);
        if (!existing.isEmpty()) return existing;

        String zip = extractZip(property.getAddress(), property.getLocation());
        if (zip == null) {
            throw new ExternalDataNotFoundException(
                    "Could not determine a ZIP code for property " + propertyId + " to query EPA Envirofacts.");
        }

        List<JsonNode> rows = epaEnvirofactsClient.findByZipCode(zip);
        if (rows.isEmpty()) {
            throw new ExternalDataNotFoundException("EPA Envirofacts has no facility records for ZIP " + zip + ".");
        }

        List<EnvironmentalRecord> records = new ArrayList<>();
        for (JsonNode row : rows) {
            records.add(EnvironmentalRecord.builder()
                    .property(property)
                    .facilityName(find(row, "PRIMARY_NAME", "FACILITY_NAME"))
                    .facilityId(find(row, "REGISTRY_ID", "FACILITY_ID"))
                    .programType(find(row, "PGM_SYS_ACRNM", "PROGRAM_TYPE", "INTEREST_TYPE"))
                    .status(find(row, "FACILITY_STATUS", "STATUS"))
                    .address(find(row, "LOCATION_ADDRESS", "ADDRESS"))
                    .latitude(findDouble(row, "LATITUDE83", "LATITUDE"))
                    .longitude(findDouble(row, "LONGITUDE83", "LONGITUDE"))
                    .source("EPA_ENVIROFACTS")
                    .build());
        }
        return environmentalRecordRepository.saveAll(records);
    }

    private String extractZip(String... candidates) {
        for (String candidate : candidates) {
            if (candidate == null) continue;
            Matcher matcher = ZIP_PATTERN.matcher(candidate);
            if (matcher.find()) return matcher.group(1);
        }
        return null;
    }

    private Property getProperty(Long id) {
        return propertyRepository.findById(id)
                .orElseThrow(() -> new ExternalDataNotFoundException("Property not found with id: " + id));
    }

    private String find(JsonNode row, String... keys) {
        for (String key : keys) {
            JsonNode value = row.get(key);
            if (value != null && !value.isNull() && StringUtils.hasText(value.asText())) return value.asText();
        }
        return null;
    }

    private Double findDouble(JsonNode row, String... keys) {
        String text = find(row, keys);
        if (text == null) return null;
        try { return Double.parseDouble(text); } catch (NumberFormatException e) { return null; }
    }
}
