package com.realestate.due_diligence_agent.dto;

import lombok.*;

import java.util.List;

@Getter @Setter @Builder @NoArgsConstructor @AllArgsConstructor
public class RiskAssessmentResponse {
    private Long reportId;
    private Long propertyId;
    private Double overallRiskScore;
    private String executiveSummary;
    private List<RiskCategoryResult> categories;
}
