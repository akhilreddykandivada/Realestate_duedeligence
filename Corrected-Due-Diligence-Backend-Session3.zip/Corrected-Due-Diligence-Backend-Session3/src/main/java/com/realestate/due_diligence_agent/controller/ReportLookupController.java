package com.realestate.due_diligence_agent.controller;

import com.realestate.due_diligence_agent.dto.ReportResponse;
import com.realestate.due_diligence_agent.service.ReportService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/** Report lookup/download endpoints, not scoped under a specific property. */
@RestController
@RequestMapping("/api/reports")
@RequiredArgsConstructor
public class ReportLookupController {

    private final ReportService reportService;

    @GetMapping("/{reportId}")
    public ResponseEntity<ReportResponse> getReport(@PathVariable Long reportId) {
        return ResponseEntity.ok(reportService.getReport(reportId));
    }

    /**
     * A given user's report history. Access-controlled: only that user
     * themselves, or an ADMINISTRATOR, can view it (enforced in
     * ReportService - throws AccessDeniedException -> 403 otherwise).
     */
    @GetMapping
    public ResponseEntity<List<ReportResponse>> getReportsForUser(@RequestParam Long user) {
        return ResponseEntity.ok(reportService.getReportsForUser(user));
    }

    @GetMapping("/{reportId}/pdf")
    public ResponseEntity<byte[]> downloadPdf(@PathVariable Long reportId) {
        byte[] pdf = reportService.getPdfBytes(reportId);
        return ResponseEntity.ok()
                .contentType(MediaType.APPLICATION_PDF)
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=report-" + reportId + ".pdf")
                .body(pdf);
    }

    @GetMapping("/{reportId}/excel")
    public ResponseEntity<byte[]> downloadExcel(@PathVariable Long reportId) {
        byte[] excel = reportService.getExcelBytes(reportId);
        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=report-" + reportId + ".xlsx")
                .body(excel);
    }
}
