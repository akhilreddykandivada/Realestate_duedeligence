package com.realestate.due_diligence_agent.comparable.client;

import com.fasterxml.jackson.databind.JsonNode;
import com.realestate.due_diligence_agent.comparable.dto.RapidApiListingResponse;
import com.realestate.due_diligence_agent.integration.ExternalApiException;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatusCode;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.util.retry.Retry;

import java.time.Duration;

/**
 * Client for a RapidAPI real-estate-listings API. Reuses the same shared
 * WebClient.Builder / retry pattern as the other integrations in this
 * project. Which specific API this calls depends entirely on what you
 * subscribe to on RapidAPI (Realty in US, Realtor, Zillow-com1, etc.) -
 * RAPIDAPI base URL, search path, and the location query-param name are
 * all externalized so you can point this at whichever one you picked
 * without touching code.
 */
@Component
@RequiredArgsConstructor
public class RapidApiListingClient {

    private final WebClient.Builder webClientBuilder;
    private WebClient webClient;

    @Value("${rapidapi.base-url:https://realty-in-us.p.rapidapi.com}")
    private String baseUrl;
    @Value("${rapidapi.search-path:/properties/v3/list-for-sale}")
    private String searchPath;
    @Value("${rapidapi.location-param:location}")
    private String locationParam;
    @Value("${rapidapi.key:${RAPIDAPI_KEY:}}")
    private String apiKey;
    @Value("${rapidapi.host:${RAPIDAPI_HOST:}}")
    private String apiHost;
    @Value("${rapidapi.retry.max-attempts:3}")
    private long maxAttempts;
    @Value("${rapidapi.retry.delay-ms:600}")
    private long retryDelayMs;

    @PostConstruct
    private void init() {
        this.webClient = webClientBuilder.baseUrl(baseUrl).build();
    }

    public RapidApiListingResponse searchListings(String locationQuery) {
        if (!StringUtils.hasText(apiKey) || !StringUtils.hasText(apiHost)) {
            throw new ExternalApiException(
                    "RapidAPI is not configured. Set RAPIDAPI_KEY and RAPIDAPI_HOST before requesting comparable listings.");
        }
        try {
            JsonNode body = webClient
                    .get()
                    .uri(uriBuilder -> uriBuilder.path(searchPath)
                            .queryParam(locationParam, locationQuery)
                            .build())
                    .header("X-RapidAPI-Key", apiKey)
                    .header("X-RapidAPI-Host", apiHost)
                    .retrieve()
                    .onStatus(HttpStatusCode::isError, status -> status.createException())
                    .bodyToMono(JsonNode.class)
                    .retryWhen(Retry.backoff(Math.max(1, maxAttempts - 1), Duration.ofMillis(Math.max(100, retryDelayMs)))
                            .filter(t -> !(t instanceof IllegalArgumentException))
                            .onRetryExhaustedThrow((spec, signal) -> new ExternalApiException(
                                    "RapidAPI listings search is temporarily unavailable.", signal.failure())))
                    .block();

            return RapidApiListingResponse.from(body);
        } catch (ExternalApiException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new ExternalApiException("Unable to process the RapidAPI listings response.", ex);
        }
    }
}
