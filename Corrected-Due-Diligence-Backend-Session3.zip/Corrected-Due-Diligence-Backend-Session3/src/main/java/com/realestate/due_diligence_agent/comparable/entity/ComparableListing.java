package com.realestate.due_diligence_agent.comparable.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.realestate.due_diligence_agent.entity.Property;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "comparable_listings")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class ComparableListing {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "property_id", nullable = false)
    private Property property;

    @Column(name = "comparable_address")
    private String comparableAddress;

    private Double price;

    @Column(name = "distance_miles")
    private Double distanceMiles;

    @Column(name = "listed_date")
    private LocalDate listedDate;

    /** e.g. "RAPIDAPI" - which external source this came from. */
    private String source;

    /** Optional supplementary fields, useful for MarketTrendService. */
    @Column(name = "square_feet")
    private Double squareFeet;

    private Double latitude;
    private Double longitude;

    @Column(name = "fetched_at", updatable = false)
    private LocalDateTime fetchedAt;

    @PrePersist
    protected void onCreate() { this.fetchedAt = LocalDateTime.now(); }
}
