package com.realestate.due_diligence_agent.comparable.controller;

import com.realestate.due_diligence_agent.comparable.entity.ComparableListing;
import com.realestate.due_diligence_agent.comparable.service.ComparableListingService;
import com.realestate.due_diligence_agent.comparable.service.MarketTrendService;
import com.realestate.due_diligence_agent.service.PropertyValueHistoryService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/properties/{id}")
@RequiredArgsConstructor
public class ComparableListingController {

    private final ComparableListingService comparableListingService;
    private final MarketTrendService marketTrendService;
    private final PropertyValueHistoryService propertyValueHistoryService;

    /** ?sortBy=distance (default) | price | listed_date */
    @GetMapping("/comparables")
    public ResponseEntity<List<ComparableListing>> getComparables(
            @PathVariable Long id,
            @RequestParam(required = false, defaultValue = "distance") String sortBy) {

        List<ComparableListing> listings = new ArrayList<>(comparableListingService.getComparables(id));

        Comparator<ComparableListing> comparator = switch (sortBy.toLowerCase()) {
            case "price" -> Comparator.comparing(ComparableListing::getPrice, Comparator.nullsLast(Double::compareTo));
            case "listed_date", "listeddate" -> Comparator.comparing(
                    ComparableListing::getListedDate, Comparator.nullsLast(Comparator.reverseOrder()));
            default -> Comparator.comparing(ComparableListing::getDistanceMiles, Comparator.nullsLast(Double::compareTo));
        };
        listings.sort(comparator);

        return ResponseEntity.ok(listings);
    }

    @GetMapping("/comparables/trends")
    public ResponseEntity<Map<String, Object>> getTrends(@PathVariable Long id) {
        return ResponseEntity.ok(marketTrendService.getTrends(id));
    }

    @GetMapping("/value-history")
    public ResponseEntity<List<Map<String, Object>>> getValueHistory(@PathVariable Long id) {
        return ResponseEntity.ok(propertyValueHistoryService.getValueHistory(id));
    }
}
