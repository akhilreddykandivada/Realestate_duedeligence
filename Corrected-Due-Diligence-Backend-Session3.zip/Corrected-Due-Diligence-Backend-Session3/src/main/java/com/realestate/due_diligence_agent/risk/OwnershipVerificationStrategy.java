package com.realestate.due_diligence_agent.risk;

import com.realestate.due_diligence_agent.dto.DueDiligenceAggregateResponse;
import com.realestate.due_diligence_agent.dto.RiskCategoryResult;
import com.realestate.due_diligence_agent.entity.OwnershipRecord;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

@Component
public class OwnershipVerificationStrategy implements RiskCategoryStrategy {

    private static final int RECENT_ACQUISITION_MONTHS = 12;

    @Override
    public String getCategory() { return "OWNERSHIP_VERIFICATION"; }

    @Override
    public double getWeight() { return 0.20; }

    @Override
    public RiskCategoryResult evaluate(DueDiligenceAggregateResponse data) {
        if (data.getOwnership() == null || !"SUCCESS".equals(data.getOwnership().getStatus())
                || data.getOwnership().getData() == null || data.getOwnership().getData().isEmpty()) {
            return RiskCategoryResult.builder()
                    .category(getCategory())
                    .score(50.0)
                    .indicator("Ownership record unavailable")
                    .notes("ATTOM ownership data could not be retrieved for this property.")
                    .build();
        }

        List<OwnershipRecord> owners = data.getOwnership().getData();
        boolean multipleOwners = owners.size() > 1;
        boolean corporateOwner = owners.stream()
                .anyMatch(o -> "Corporate".equalsIgnoreCase(o.getOwnershipType()));

        LocalDate mostRecentAcquisition = owners.stream()
                .map(OwnershipRecord::getAcquisitionDate)
                .filter(java.util.Objects::nonNull)
                .max(LocalDate::compareTo)
                .orElse(null);

        boolean recentAcquisition = mostRecentAcquisition != null
                && ChronoUnit.MONTHS.between(mostRecentAcquisition, LocalDate.now()) < RECENT_ACQUISITION_MONTHS;

        double score = 15.0;
        StringBuilder notes = new StringBuilder();
        notes.append(owners.size()).append(" owner record(s) on file.");

        if (multipleOwners) {
            score += 20;
            notes.append(" Multiple/joint ownership can complicate title transfer.");
        }
        if (recentAcquisition) {
            score += 25;
            notes.append(" Most recent acquisition (" + mostRecentAcquisition + ") was within the last "
                    + RECENT_ACQUISITION_MONTHS + " months - flips/rapid resales warrant extra title scrutiny.");
        }
        if (mostRecentAcquisition == null) {
            score += 10;
            notes.append(" Acquisition date not on record from this data source.");
        }

        String indicator = multipleOwners && recentAcquisition
                ? "Multiple owners with a recent acquisition"
                : multipleOwners ? "Multiple/joint ownership on record"
                : recentAcquisition ? "Recently acquired property"
                : "Single long-standing owner on record";

        return RiskCategoryResult.builder()
                .category(getCategory())
                .score(Math.min(95.0, score))
                .indicator(indicator + (corporateOwner ? " (corporate owner)" : ""))
                .notes(notes.toString())
                .build();
    }
}
