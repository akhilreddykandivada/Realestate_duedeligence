package com.realestate.due_diligence_agent.controller;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.realestate.due_diligence_agent.entity.*;
import com.realestate.due_diligence_agent.integration.epa.EpaEnvirofactsClient;
import com.realestate.due_diligence_agent.repository.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDate;
import java.util.List;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Exercises the real aggregation endpoint end-to-end through the actual
 * Spring Security filter chain (MockMvc), backed by an in-memory H2
 * database (see application-test.properties) instead of a real Postgres
 * instance.
 *
 * Strategy: since every one of the seven services is "database-first"
 * (check the DB before ever calling an external API), six of the seven
 * sections are pre-seeded directly via their repositories so no external
 * client needs to be mocked for them at all. Only EPA Envirofacts is
 * mocked, since the environmental-records table is deliberately left
 * empty so its behavior (success vs. failure) can be controlled per test.
 */
@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
class DueDiligenceAggregationIntegrationTest {

    @Autowired MockMvc mockMvc;
    @Autowired PropertyRepository propertyRepository;
    @Autowired OwnershipRecordRepository ownershipRecordRepository;
    @Autowired TaxHistoryRepository taxHistoryRepository;
    @Autowired ZoningInformationRepository zoningInformationRepository;
    @Autowired FloodZoneDataRepository floodZoneDataRepository;
    @Autowired PermitRepository permitRepository;
    @Autowired UtilityInformationRepository utilityInformationRepository;
    @Autowired UserRepository userRepository;
    @Autowired PasswordEncoder passwordEncoder;
    @Autowired ObjectMapper objectMapper;

    @MockitoBean
    EpaEnvirofactsClient epaEnvirofactsClient;

    private Long fullySeededPropertyId;
    private Long noZipPropertyId;

    @BeforeEach
    void setUp() {
        if (userRepository.findByEmail("qa-tester@example.com").isEmpty()) {
            userRepository.save(User.builder()
                    .fullName("QA Tester")
                    .email("qa-tester@example.com")
                    .password(passwordEncoder.encode("Password123!"))
                    .role(Role.BUYER)
                    .build());
        }

        fullySeededPropertyId = seedFullySeededProperty();
        noZipPropertyId = seedPropertyWithNoZip();
    }

    @Test
    @WithMockUser(username = "qa-tester@example.com")
    void aggregationEndpoint_returnsAllSevenSections_whenEveryServiceSucceeds() throws Exception {
        JsonNode epaRow = objectMapper.readTree("""
                {"PRIMARY_NAME":"Test Facility","REGISTRY_ID":"TEST123","PGM_SYS_ACRNM":"FRS",
                 "FACILITY_STATUS":"ACTIVE","LOCATION_ADDRESS":"123 Main St","LATITUDE83":"39.7",
                 "LONGITUDE83":"-104.9"}
                """);
        when(epaEnvirofactsClient.findByZipCode(anyString())).thenReturn(List.of(epaRow));

        mockMvc.perform(get("/api/properties/{id}/due-diligence", fullySeededPropertyId))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.ownership.status").value("SUCCESS"))
                .andExpect(jsonPath("$.taxHistory.status").value("SUCCESS"))
                .andExpect(jsonPath("$.zoning.status").value("SUCCESS"))
                .andExpect(jsonPath("$.floodZone.status").value("SUCCESS"))
                .andExpect(jsonPath("$.permits.status").value("SUCCESS"))
                .andExpect(jsonPath("$.environmental.status").value("SUCCESS"))
                .andExpect(jsonPath("$.utilities.status").value("SUCCESS"))
                .andExpect(jsonPath("$.environmental.data[0].facilityName").value("Test Facility"));
    }

    @Test
    @WithMockUser(username = "qa-tester@example.com")
    void aggregationEndpoint_returnsOtherSixSections_whenOneServiceFails() throws Exception {
        // No mocking needed - this property has no extractable ZIP code, so
        // EnvironmentalRecordService fails for a real, natural reason
        // (ExternalDataNotFoundException) without ever touching the EPA client.
        mockMvc.perform(get("/api/properties/{id}/due-diligence", noZipPropertyId))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.ownership.status").value("SUCCESS"))
                .andExpect(jsonPath("$.taxHistory.status").value("SUCCESS"))
                .andExpect(jsonPath("$.zoning.status").value("SUCCESS"))
                .andExpect(jsonPath("$.floodZone.status").value("SUCCESS"))
                .andExpect(jsonPath("$.permits.status").value("SUCCESS"))
                .andExpect(jsonPath("$.utilities.status").value("SUCCESS"))
                .andExpect(jsonPath("$.environmental.status").value("FAILED"))
                .andExpect(jsonPath("$.environmental.errorMessage").isNotEmpty());
    }

    private Long seedFullySeededProperty() {
        Property property = propertyRepository.save(Property.builder()
                .address("100 Test Ave")
                .location("Denver, CO 80212")
                .type("SINGLE_FAMILY")
                .bedrooms(3)
                .bathrooms(2)
                .squareFeet(1500.0)
                .yearBuilt(1990)
                .latitude(39.7)
                .longitude(-104.9)
                .build());

        ownershipRecordRepository.save(OwnershipRecord.builder()
                .property(property).ownerName("Jane Doe").ownershipType("Individual").build());

        taxHistoryRepository.save(TaxHistory.builder()
                .property(property).taxYear(2025).assessedValue(350000.0).taxAmount(4200.0)
                .paymentStatus("CURRENT").build());

        zoningInformationRepository.save(ZoningInformation.builder()
                .property(property).zoningClassification("R-1").landUse("Residential")
                .zoningCompliance("COMPLIANT").build());

        floodZoneDataRepository.save(FloodZoneData.builder()
                .property(property).floodZone("X").floodRiskRating("MINIMAL").source("FEMA_NFHL").build());

        permitRepository.save(Permit.builder()
                .property(property).permitNumber("P-2020-001").permitType("Roof").status("FINALED")
                .issueDate(LocalDate.of(2020, 5, 1)).finalDate(LocalDate.of(2020, 6, 1)).source("SHOVELS").build());

        utilityInformationRepository.save(UtilityInformation.builder()
                .property(property).utilityType("Water").providerName("Denver Water").source("QA Tester").build());

        return property.getId();
    }

    private Long seedPropertyWithNoZip() {
        Property property = propertyRepository.save(Property.builder()
                .address("Unknown Location")
                .location(null)
                .type("SINGLE_FAMILY")
                .latitude(39.7)
                .longitude(-104.9)
                .build());

        ownershipRecordRepository.save(OwnershipRecord.builder()
                .property(property).ownerName("John Roe").ownershipType("Individual").build());
        taxHistoryRepository.save(TaxHistory.builder()
                .property(property).taxYear(2025).assessedValue(200000.0).taxAmount(2000.0)
                .paymentStatus("CURRENT").build());
        zoningInformationRepository.save(ZoningInformation.builder()
                .property(property).zoningClassification("R-1").landUse("Residential").build());
        floodZoneDataRepository.save(FloodZoneData.builder()
                .property(property).floodZone("X").floodRiskRating("MINIMAL").source("FEMA_NFHL").build());
        permitRepository.save(Permit.builder()
                .property(property).permitNumber("P-2021-002").permitType("Fence").status("FINALED").source("SHOVELS").build());
        utilityInformationRepository.save(UtilityInformation.builder()
                .property(property).utilityType("Electric").providerName("Xcel Energy").source("QA Tester").build());

        return property.getId();
    }
}
