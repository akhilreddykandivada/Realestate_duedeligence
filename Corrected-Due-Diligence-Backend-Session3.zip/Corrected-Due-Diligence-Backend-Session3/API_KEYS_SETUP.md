# ATTOM and REGRID API setup

The backend keeps the verified ATTOM integration for:
- `/property/basicprofile`
- `/property/detailowner`
- `/assessment`

It also keeps the REGRID parcel lookup integration used for zoning/land-use data.

## 1. Set environment variables (Windows PowerShell)

Set your real credentials locally; do not put them into `application.properties`.

```powershell
$env:DB_PASSWORD="YOUR_POSTGRES_PASSWORD"
$env:JWT_SECRET="YOUR_LONG_RANDOM_JWT_SECRET"
$env:ATTOM_API_KEY="YOUR_ATTOM_API_KEY"
$env:REGRID_API_TOKEN="YOUR_REGRID_API_TOKEN"
```

Optional: if your Regrid account requires Bearer authentication instead of the query-token mode used by this prototype:

```powershell
$env:REGRID_AUTH_MODE="BEARER"
```

## 2. Database

The default database is `realestate_due_diligence`. Override it only if needed:

```powershell
$env:DB_NAME="realestate_due_diligence"
```

## 3. Important

The project does **not** contain real ATTOM/REGRID credentials. The values must come from your ATTOM and Regrid accounts.

The ATTOM client sends `apikey` and uses `address1` + `address2`, matching the previously verified working request format. The owner-details endpoint is `/property/detailowner`; basic property details use `/property/basicprofile`.

REGRID receives latitude/longitude from the validated property and performs parcel lookup.
