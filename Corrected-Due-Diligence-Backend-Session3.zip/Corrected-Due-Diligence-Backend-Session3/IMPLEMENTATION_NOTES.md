# Real Estate Due Diligence Agent — implementation notes

## Existing modules preserved

- JWT authentication and Spring Security RBAC
- User registration/login and profile management
- Property search and property details
- Address validation through Google Geocoding with the documented Nominatim fallback
- Property history
- Administrator property-owner assignment
- React frontend with protected routes

## New mentor task implemented

### Backend

1. Added JPA entities:
   - `OwnershipRecord`
   - `TaxHistory`
   - `ZoningInformation`
2. Added repositories for the three new entities.
3. Added ATTOM WebClient integration for:
   - `/property/basicprofile`
   - `/property/detailowner`
   - `/assessment`
4. Added REGRID WebClient parcel lookup integration.
5. ATTOM API key is sent using the `apikey` request header.
6. REGRID supports both `BEARER` and `QUERY` authentication through configuration.
7. Added provider-response DTOs for the ATTOM response envelope/property data and the REGRID GeoJSON parcel response.
8. Added `DueDiligenceService` to coordinate API calls, response mapping, persistence and cached reads.
9. Added endpoints:
   - `GET /api/properties/{id}/ownership`
   - `GET /api/properties/{id}/tax-history`
   - `GET /api/properties/{id}/zoning`
10. Added explicit handling for missing properties, missing external data, provider failures and invalid responses.

### Frontend

- Reworked the property workspace to focus on meaningful due-diligence actions.
- Added Ownership, Tax History and Zoning cards to the property details page.
- Added individual loading/error states and a `Run all checks` action.
- Added frontend API methods for all three new endpoints.
- Kept the existing login, registration, profile, address validation and property history workflows.
- Refreshed the visual hierarchy, spacing, property summary and due-diligence cards without adding a UI library dependency.

## Environment variables

Required for the existing application:

```text
DB_PASSWORD
JWT_SECRET              # recommended; the project still has a development fallback
GOOGLE_MAPS_API_KEY     # existing Google geocoding setup
```

Required for the new mentor task:

```text
ATTOM_API_KEY
REGRID_API_TOKEN
```

Optional provider configuration:

```text
ATTOM_BASE_URL
ATTOM_BASIC_PROFILE_PATH
ATTOM_DETAIL_OWNER_PATH
ATTOM_ASSESSMENT_PATH
REGRID_BASE_URL
REGRID_PARCEL_PATH
REGRID_AUTH_MODE       # BEARER (default) or QUERY
REGRID_TOKEN_QUERY_PARAM
```

The project intentionally does not contain real API credentials.

## Google setup reminder

The existing Google Geocoding integration is still present. Google is attempted first. If the configured Google key is rejected because of billing/project restrictions and fallback is enabled, the documented Nominatim prototype fallback can still return coordinates.

## ATTOM setup reminder

Create an ATTOM developer account, obtain the trial/active API key, and set it as `ATTOM_API_KEY`. The backend sends it in the `apikey` header. The trial is time-limited according to the project's API integration guide.

## REGRID setup reminder

Create a REGRID developer account/token and set it as `REGRID_API_TOKEN`. The default configuration uses Bearer authentication. If the provider documentation for the issued account requires a query parameter instead, set `REGRID_AUTH_MODE=QUERY` and keep the configured token parameter name in `REGRID_TOKEN_QUERY_PARAM`.

## Important testing behavior

The three new due-diligence GET operations use a simple database cache. On the first request for a property, the backend calls the external provider, maps the response and saves it. Later requests return the saved records instead of repeatedly consuming paid/trial API calls.

## Session 3 additions (this round)

### Report generation pipeline
- `ReportStatus` enum (`REQUESTED`/`IN_PROGRESS`/`COMPLETED`/`FAILED`) replaces the old free-form status String
- `Report` gained: `requestedByUser` (real FK for access control), `propertyTimeline` (JSON), `pdfUrl`, `excelUrl`, `failureReason`
- `PropertyTimelineBuilder` - builds a chronological timeline from ownership/tax/permit data (no new external calls)
- `GET /api/properties/{id}/history` now returns this real timeline instead of the old internal sync-event audit log
- `ExecutiveSummaryGenerator` - template-based (no AI), uses overall risk score + leading risk category + comparable-listings average price
- `ReportService.generateReport(propertyId)` - the full pipeline: gather due-diligence data → risk assessment → comparable listings (best-effort) → timeline → summary → PDF/Excel export (best-effort) → COMPLETED, or FAILED with a reason on error
- `POST /api/properties/{id}/reports` now runs this full pipeline (previously created an empty shell)
- `POST /api/properties/{id}/risk-assessment` kept as a separate, faster, risk-only endpoint
- `GET /api/reports/{id}` - full report detail
- `GET /api/reports?user={userId}` - a user's report history, access-controlled (self or ADMINISTRATOR only, else 403)
- `GET /api/reports/{id}/pdf`, `GET /api/reports/{id}/excel` - file downloads

### Comparable Listings module (new `comparable/` package)
- `ComparableListing` entity, repository, `RapidApiListingResponse` DTO, `RapidApiListingClient`, `DistanceCalculator` (Haversine, pure static utility), `ComparableListingService` (database-first, 30-day staleness), `MarketTrendService` (average price, average price/sqft, recency-weighted average - computed only from already-saved data, no new API calls), `ComparableListingController`
- **Needs verification**: I do not have a RapidAPI account, so `RapidApiListingResponse` and the field-mapping in `ComparableListingService.mapListing(...)` are built defensively (won't crash on unexpected fields) but are NOT verified against a real response. Test with your own RapidAPI subscription and adjust the candidate field-name lists if anything comes back null that shouldn't.
- `GET /api/properties/{id}/comparables?sortBy=distance|price|listed_date`
- `GET /api/properties/{id}/comparables/trends`
- `GET /api/properties/{id}/value-history` (reuses tax history, no new table)

### PDF/Excel generation (new `report/` package)
- `PdfReportGenerator` (iText 9.7.1) - title/address, executive summary, risk table, timeline, comparable listings table
- `ExcelReportGenerator` (Apache POI 5.5.1) - 4 sheets: Summary, Risk Assessment, Comparable Listings, Timeline
- `FileStorageService` - saves to local disk (`REPORT_STORAGE_DIRECTORY`, default `./generated-reports`); files are served back out through the authenticated download endpoints above, not a public static path

### New config required
- `RAPIDAPI_KEY`, `RAPIDAPI_HOST` (get from your own RapidAPI subscription), `RAPIDAPI_BASE_URL`/`RAPIDAPI_SEARCH_PATH`/`RAPIDAPI_LOCATION_PARAM` (only if your chosen API differs from the `realty-in-us` default)
- `REPORT_STORAGE_DIRECTORY` (optional, defaults to `./generated-reports`)

### Database
`reports` and `risk_assessments` changed shape significantly (enum-backed status, several new columns) and `comparable_listings` is brand new. Since you already have test rows in `reports`/`risk_assessments` from earlier sessions, **drop both tables** (see `database/session3_report_and_comparables.sql`) and let `ddl-auto=update` recreate them on next startup - same pattern as the earlier `address` column issue.
